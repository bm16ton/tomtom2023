#include "main.h"

#define ANIMATION_PER_CALL 1

Normal_Animation::Normal_Animation(int x_center, int y_center, SDL_Surface **array_image)
{
	this->_discontinue = 0;
	this->array_current = -1;
	this->ticker = 0;
	
	//set the centers...
	this->x_center = x_center;
	this->y_center = y_center;
	this->array_image = array_image;
}

Normal_Animation::~Normal_Animation()
{
	
}

void Normal_Animation::display_next_image()
{
	int next_tobe;
	
	ticker += ANIMATION_PER_CALL;
	
	next_tobe = (int)ticker;
	
	//dont display something that was already displayed
	if(next_tobe == this->array_current)
		return;
	
	//display the next image
	this->array_current = next_tobe;
	
	//display if it exists
	if(!this->array_image[this->array_current]) 
		return;
	
	main_game->draw_noflip(this->x_center - (this->array_image[this->array_current]->w / 2), this->y_center - (this->array_image[this->array_current]->h / 2), this->array_image[this->array_current]);
	
}

int Normal_Animation::EOL()
{
	if(this->array_current > -1 && !this->array_image[this->array_current]) return 1;
	if(this->_discontinue) return 1;
	return 0;
}

void Normal_Animation::discontinue()
{
	this->_discontinue = 1;
}
