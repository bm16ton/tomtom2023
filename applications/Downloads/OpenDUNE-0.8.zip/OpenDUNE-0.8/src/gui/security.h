/** @file src/security.h Security definitions. */

#ifndef SECURITY_H
#define SECURITY_H

bool GUI_Security_Show(void);

#endif /* SECURITY_H */
