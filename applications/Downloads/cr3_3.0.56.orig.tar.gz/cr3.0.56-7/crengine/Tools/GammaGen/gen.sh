g++ -o ./gammagen gammagen.cpp
./gammagen ../../include/gammatbl.h
rm -f ./gammagen
