typedef struct {
   unsigned char ch1;
   unsigned char ch2;
   short    count;
} dbl_char_stat_t;

typedef struct {
   unsigned char ch1;
   unsigned char ch2;
   int      count;
} dbl_char_stat_long_t;
