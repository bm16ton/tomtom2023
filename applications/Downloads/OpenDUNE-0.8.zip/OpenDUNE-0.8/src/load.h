/** @file src/load.h Load definitions. */

#ifndef LOAD_H
#define LOAD_H

extern bool SaveGame_LoadFile(char *filename);
extern void Load_Palette_Mercenaries(void);

#endif /* LOAD_H */
