#include "main.h"

Screen_Layout::Screen_Layout()
{
	this->button_max = 0;
	this->backround = 0;
	this->func_load = 0;
	this->func_buttonover = 0;
	this->func_buttonpress = 0;
	
	//"stop" the animator thread
	this->animator_thread = 0;
}

Screen_Layout::~Screen_Layout()
{
	
}

void Screen_Layout::show()
{
	if(this->backround)
		main_game->draw(0,0,this->backround);
	
	if(this->func_load)
		this->func_load();
}

# ifdef CAANOO
static void caanoo_scale_xy( int& x, int& y )
{
  x = (x * 640) / 320;
  y = (y * 520) / 240;
}
# endif

void Screen_Layout::do_mousepress(int x, int y)
{
	int i;
# ifdef CAANOO
  caanoo_scale_xy( x, y );
# endif

	if(!this->func_buttonpress) return;

	for(i=0;i<this->button_max;i++)
		if(this->button[i]->is_active() && this->button[i]->within_boundary(x,y))
	{
			this->func_buttonpress(i);
			break;
	}
}

void Screen_Layout::do_mousemovement(int x, int y)
{
	int i;
	int is_over;

# ifdef CAANOO
  caanoo_scale_xy( x, y );
# endif
	
	if(this->func_buttonover)
	{
		for(i=0;i<this->button_max;i++)
			if(this->button[i]->is_active() && (is_over = this->button[i]->test_for_draw(x,y)))
		{
				this->func_buttonover(i,is_over - 1);
				break;
		}
	}
	else
	{
		for(i=0;i<this->button_max;i++)
			if(this->button[i]->is_active())
		{
				this->button[i]->test_for_draw(x,y);
				break;
		}
	}
}

void Screen_Layout::load_backround(char *backround_filename)
{
	this->backround = SDL_LoadBMP(backround_filename);
}

SDL_Surface *Screen_Layout::get_backround()
{
	return this->backround;
}

void Screen_Layout::set_load_func(void (*func_ptr)(void))
{
	this->func_load = func_ptr;
}

void Screen_Layout::set_buttonpress_func(void (*func_ptr)(int i))
{
	this->func_buttonpress = func_ptr;
}

void Screen_Layout::set_buttonover_func(void (*func_ptr)(int i, bool is_overtop))
{
	this->func_buttonover = func_ptr;
}

int Screen_Layout::make_button(int x, int y, char *button_filename, int w, int h)
{
	int i;
	
	i = this->button_max;
	
	this->button[i] = new Screen_Button();
	
	this->button[i]->override_boundaries(x,y,w,h);
	
	if(button_filename) this->button[i]->load_mouse_off_img(button_filename);
	
	//increase the max
	this->button_max++;
	
	return i;
}

Screen_Button *Screen_Layout::get_button(int button_num)
{
		//check if valid
	if(button_num < 0) return 0;
	if(button_num >= this->button_max) return 0;

	//do code
	return this->button[button_num];
}

bool Screen_Layout::doing_score_animation()
{
	if(!this->animator_run) return 0;
	return (this->anim_score);
}

bool Screen_Layout::doing_trial_timer_animation()
{
	if(!this->animator_run) return 0;
	return (this->anim_trail_timer);
}
		
void Screen_Layout::start_animator_engine()
{
	int i;
	
	//dont make copies.....
	if(this->animator_thread) return;
	
	//kill all the animators
	for(i=0;i<NORMAL_ANIM_MAX;i++)
		this->anim_norm[i] = 0;
	for(i=0;i<DROP_ANIM_MAX;i++)
		this->anim_drop[i] = 0;
	for(i=0;i<POINT_ANIM_MAX;i++)
		this->anim_point[i] = 0;
	this->anim_selector = 0;
	this->anim_swap = 0;
	this->anim_score = 0;
	this->anim_score_disolve = 0;
	this->anim_trail_timer = 0;
	
	//needed to keep this upcoming thread going
	this->animator_run = 1;
	
	this->animator_thread = SDL_CreateThread(animator_func, (void*)this);
}

void Screen_Layout::stop_animator_engine()
{
	//is it even running....
	if(!this->animator_thread) return;
	
	//tell the thread to stop
	this->animator_run = 0;
	
	//wait until it does...
	while(this->animator_thread)
		SDL_Delay(40);
}

void Screen_Layout::start_point_animation(int i, int k, int points_added)
{
	int z;
	const int x_start = 205;
	const int y_start = 60;
	const int y_spacer = 47;
	const int x_spacer = 50;
	
	//find an avaible animator slot
	for(z=0;z<POINT_ANIM_MAX;z++)
		if(!this->anim_point[z])
			break;
	
	//now found eh?
	if(z==POINT_ANIM_MAX) return;
	
	//praise the jesus
	this->anim_point[z] = new Point_Animation(x_start + (i * x_spacer),y_start + (k * y_spacer),points_added);
}

void Screen_Layout::start_round_animation(int round_num)
{
	//we already got it going on?
	if(this->anim_round)
	{
		//kill it...
		this->anim_round->discontinue();
		
		//wait until its gone.
		while(this->anim_round)
			SDL_Delay(40);
	}
	
	this->anim_round = new Round_Animation(round_num);
}

void Screen_Layout::start_trial_timer_animation()
{
		//we already got it going on?
	if(this->anim_trail_timer)
	{
		//kill it...
		this->anim_trail_timer->discontinue();
		
		//wait until its gone.
		while(this->anim_trail_timer)
			SDL_Delay(40);
	}
	
	this->anim_trail_timer = new Trial_Timer_Animation();
}

void Screen_Layout::start_score_disolve_animation()
{	//we already got it going on?
	if(this->anim_score_disolve)
	{
		//kill it...
		this->anim_score_disolve->discontinue();
		
		//wait until its gone.
		while(this->anim_score_disolve)
			SDL_Delay(40);
	}
	
	this->anim_score_disolve = new Score_Disolve_Animation();
}

void Screen_Layout::start_score_animation(int current_score, int new_score)
{
	//we already got it going on?
	if(this->anim_score)
	{
		//put in the new score for it to run to
		this->anim_score->set_new_new_score(new_score);
	}
	else
	{
		//make it if not
		this->anim_score = new Score_Animation(current_score, new_score);
	}
}

void Screen_Layout::start_animation(int index, SDL_Surface *animation_array[])
{
	int i,k,x,y;
	const int x_start = 205;
	const int y_start = 60;
	const int y_spacer = 47;
	const int x_spacer = 50;
	
	//find what our x and y are going to be
	i = index / 8;
	k = index % 8;
	
	//check if we are swapping this atm
	if(this->anim_swap && this->anim_swap->is_swapping_index(index)) return;
	
	//check if this apart of a dropping row...
	if(this->anim_drop[i] && this->anim_drop[i]->get_to() >= k) return;
	
	//we already got it going on?
	if(this->anim_norm[index])
	{
		//kill it...
		this->anim_norm[index]->discontinue();
		
		//wait until its gone.
		while(this->anim_norm[index])
			SDL_Delay(40);
	}
	
	x = x_start + (i * x_spacer) + 17;
	y = y_start + (k * y_spacer) + 17;
	
	//make our new animation
	this->anim_norm[index] = new Normal_Animation(x,y,animation_array);
}

void Screen_Layout::start_drop_row_animation(int i, int to, int from)
{
	int z;
	
	//we already got it going on?
	if(this->anim_drop[i])
	{
		//is it already covering more then we are?
		if(this->anim_drop[i]->get_to() > to)
			return;
		
		//kill it...
		this->anim_drop[i]->discontinue();
		
		//wait until its gone.
		while(this->anim_drop[i])
			SDL_Delay(40);
	}
	
	//kill all animations above the point where we are dropping to
	for(z=to;z>=0;z--)
		if(this->anim_norm[z])
	{
		//kill it...
		this->anim_norm[z]->discontinue();
		
		//wait until its gone.
		while(this->anim_norm[z])
			SDL_Delay(40);
	}

	//make our new animation
	this->anim_drop[i] = new Drop_Animation(i,to, from);
}

void Screen_Layout::start_selector_animation(int index)
{
	//we already have one going?
	if(this->anim_selector)
	{
		//kill it...
		this->anim_selector->discontinue();
		
		//wait until its gone.
		while(this->anim_selector)
			SDL_Delay(40);
	}
	
	//create it !
	this->anim_selector = new Selector_Animation(index);
}

void Screen_Layout::start_swap_animation(int i1, int k1, int i2, int k2, bool is_good)
{
	int index1, index2;
	
	//we already have one going?
	if(this->anim_swap)
	{
		//kill it...
		this->anim_swap->discontinue();
		
		//wait until its gone.
		while(this->anim_swap)
			SDL_Delay(40);
	}
	
	//kill any animations on this index
	index1 = (i1 * 8) + k1;
	index2 = (i2 * 8) + k2;
	
	if(this->anim_norm[index1])
	{
		//kill it...
		this->anim_norm[index1]->discontinue();
		
		//wait until its gone.
		while(this->anim_norm[index1])
			SDL_Delay(40);
	}
	
	if(this->anim_norm[index2])
	{
		//kill it...
		this->anim_norm[index2]->discontinue();
		
		//wait until its gone.
		while(this->anim_norm[index2])
			SDL_Delay(40);
	}
	
	//create it !
	this->anim_swap = new Swap_Animation(i1, k1, i2, k2, is_good);
}

void Screen_Layout::stop_selector_animation()
{
	//if it exists of course
	if(this->anim_selector)
		this->anim_selector->discontinue();
}

void Screen_Layout::pause_while_drop()
{
	int i;
	
	while(this->animator_run)
	{
		for(i=0;i<DROP_ANIM_MAX;i++)
			if(this->anim_drop[i])
				break;
		
		if(i==DROP_ANIM_MAX)
			break;
		
		SDL_Delay(40);
	}
}

int animator_func(void *nothing)
{
	Screen_Layout *this_layout;
	double last_draw_time;
	int i;
	int do_flip, do_flip_layered, undobackup;
	
	//setup our synthetic this
	this_layout = (Screen_Layout*)nothing;

	last_draw_time = main_game->current_time();
	
	while(this_layout->animator_run)
	{
		do_flip = 0;
		do_flip_layered = 0;
		undobackup = 0;
		
		if(main_game->current_time() - last_draw_time >= ANIMATIONS_INTERVAL)
		{
			//check out all of our posibilties
			for(i=0;i<NORMAL_ANIM_MAX;i++)
				if(this_layout->anim_norm[i])
			{
				if(this_layout->anim_norm[i]->EOL())
				{
					//delete the object
					delete this_layout->anim_norm[i];
					this_layout->anim_norm[i] = 0;
				}
				else
				{
					//display its next image...
					this_layout->anim_norm[i]->display_next_image();
					do_flip = 1;
				}
			}
			
			//do do drop animation while swapping is going on..
			if(!this_layout->anim_swap)
			for(i=0;i<DROP_ANIM_MAX;i++)
				if(this_layout->anim_drop[i])
			{
				if(this_layout->anim_drop[i]->EOL())
				{
					//delete the object
					delete this_layout->anim_drop[i];
					this_layout->anim_drop[i] = 0;
				}
				else
				{
					//display its next image...
					this_layout->anim_drop[i]->display_next_image();
					do_flip = 1;
				}
			}
			
			if(this_layout->anim_selector)
			{
				if(this_layout->anim_selector->EOL())
				{
					//delete the object
					delete this_layout->anim_selector;
					this_layout->anim_selector = 0;
				}
				else
				{
					this_layout->anim_selector->display_next_image();
				}
				
				do_flip = 1;
			}
			
			if(this_layout->anim_score)
			{
				if(this_layout->anim_score->EOL())
				{
					//delete the object
					delete this_layout->anim_score;
					this_layout->anim_score = 0;
				}
				else
				{
					this_layout->anim_score->display_next_image();
					do_flip = 1;
				}
			}
			else
			{
				if(this_layout->anim_score_disolve)
				{
					if(this_layout->anim_score_disolve->EOL())
					{
						//delete the object
						delete this_layout->anim_score_disolve;
						this_layout->anim_score_disolve = 0;
						
						this_layout->animator_thread = 0;
						return 0;
					}
					else
					{
						this_layout->anim_score_disolve->display_next_image();
						do_flip = 1;
					}
				}
			}
			
			if(this_layout->anim_swap)
				if(this_layout->anim_swap->EOL())
				{
					//delete the object
					delete this_layout->anim_swap;
					this_layout->anim_swap = 0;
				}
				else
				{
					this_layout->anim_swap->display_next_image();
					do_flip = 1;
				}
				
			if(IS_TRIAL)
				if(this_layout->anim_trail_timer)
					if(this_layout->anim_trail_timer->EOL())
			{
				//delete the object
				delete this_layout->anim_trail_timer;
				this_layout->anim_trail_timer = 0;
			}
			else
			{
				this_layout->anim_trail_timer->display_next_image();
				do_flip = 1;
			}
			
			//now for the second layer stuff
				
				
			if(IS_TRIAL && 0)
				if(this_layout->anim_trail_timer)
					if(this_layout->anim_trail_timer->EOL())
			{
				//delete the object
				delete this_layout->anim_trail_timer;
				this_layout->anim_trail_timer = 0;
			}
			else
			{
				//needed to add another quick layer
				if(!undobackup)
				{
					main_game->backup_screen();
					undobackup = 1;
				}
					
				this_layout->anim_trail_timer->display_next_image();
				do_flip = 1;
			}
				
			for(i=0;i<POINT_ANIM_MAX;i++)
				if(this_layout->anim_point[i])
			{
				if(this_layout->anim_point[i]->EOL())
				{
				//delete the object
					delete this_layout->anim_point[i];
					this_layout->anim_point[i] = 0;
					do_flip = 1;
				}
				else
				{
					//needed to add another quick layer
					if(!undobackup)
					{
						main_game->backup_screen();
						undobackup = 1;
					}
					
				//display its next image...
					this_layout->anim_point[i]->display_next_image();
					do_flip = 1;
				}
			}
				
			if(this_layout->anim_round)
				if(this_layout->anim_round->EOL())
				{
					//delete the object
					delete this_layout->anim_round;
					this_layout->anim_round = 0;
				}
				else
				{
					//needed to add another quick layer
					if(!undobackup)
					{
						main_game->backup_screen();
						undobackup = 1;
					}
					
					this_layout->anim_round->display_next_image();
					do_flip = 1;
				}
				
			
			if(do_flip)
				main_game->flip_screen();
			
			if(undobackup)
				main_game->unbackup_screen();
			
			
			last_draw_time = main_game->current_time();
		}
	
		SDL_Delay(9);
	}
	
	this_layout->animator_thread = 0;
}



