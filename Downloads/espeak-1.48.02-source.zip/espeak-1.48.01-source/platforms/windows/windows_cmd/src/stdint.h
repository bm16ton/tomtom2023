
// dummy stdint.h file for Windows

typedef unsigned int  uint32_t;
