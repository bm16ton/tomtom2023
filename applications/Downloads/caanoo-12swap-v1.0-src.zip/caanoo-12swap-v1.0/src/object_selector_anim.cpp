#include "main.h"

#define TICKS_MAX 30;
#define TICK_INCREASE PI / TICKS_MAX
#define TICK_BUFFER 50

Selector_Animation::Selector_Animation(int index)
{
	int i,k;
	const int x_start = 200;
	const int y_start = 55;
	const int y_spacer = 47;
	const int x_spacer = 50;
	
	i = index / 8;
	k = index % 8;
	
	this->i = i;
	this->k = k;
	this->ticker = 0;
	this->back_round = 0;
	this->_discontinue = 0;
	
	//set the boundaries
	this->y = y_start + (k * y_spacer);
	this->x = x_start + (i * x_spacer);
	
	this->create_backround();
}

Selector_Animation::~Selector_Animation()
{
	if(this->back_round)
	{
		//draw our final good bye
		main_game->draw_noflip(this->x,this->y,this->back_round);
		
		//and turn to dust
		SDL_FreeSurface(this->back_round);
	}
}

void Selector_Animation::display_next_image()
{
	//clear out space
	if(this->back_round)
		main_game->draw_noflip(this->x,this->y,this->back_round);
	
	//set new alpha
	SDL_SetAlpha(game_selector,SDL_RLEACCEL|SDL_SRCALPHA,(int)((255 - (TICK_BUFFER * 2)) * fabs(sin(ticker))) + TICK_BUFFER);
	
	//increase ticker
	ticker += TICK_INCREASE;
	
	//draw in new
	main_game->draw_noflip(this->x,this->y,game_selector);
}

void Selector_Animation::create_backround()
{
	Uint32 rmask, gmask, bmask, amask;
	SDL_Rect destination, crop_area;
	
	//set some defaults...
	destination.x = 0;
	destination.y = 0;
	destination.w = 49;
	destination.h = 47;
	crop_area.x = this->x;
	crop_area.y = this->y;
	crop_area.w = 49;
	crop_area.h = 47;

  SDL_Surface* g_main_screen = SDL_GetVideoSurface();
  rmask = g_main_screen->format->Rmask;
  gmask = g_main_screen->format->Gmask;
  bmask = g_main_screen->format->Bmask;
  amask = g_main_screen->format->Amask;
  int num_bits = g_main_screen->format->BitsPerPixel;
	//create the surface
	this->back_round = SDL_CreateRGBSurface(SDL_HWSURFACE | SDL_SRCCOLORKEY, 49, 47, num_bits, rmask, gmask, bmask, amask);
	
	//place the backround on it
	SDL_BlitSurface(main_game->get_screen(screen_game)->get_backround(), &crop_area, this->back_round, &destination);
	
	//cut out the center
	crop_area.x = 5;
	crop_area.y = 5;
	crop_area.w = 39;
	crop_area.h = 37;
	SDL_FillRect(this->back_round,&crop_area,SDL_MapRGBA(this->back_round->format, 0,0,0,0));
	SDL_SetColorKey(this->back_round, SDL_SRCCOLORKEY, SDL_MapRGBA(this->back_round->format, 0,0,0,0));
}

int Selector_Animation::EOL()
{
	return this->_discontinue;
}

void Selector_Animation::discontinue()
{
	this->_discontinue = 1;
}

