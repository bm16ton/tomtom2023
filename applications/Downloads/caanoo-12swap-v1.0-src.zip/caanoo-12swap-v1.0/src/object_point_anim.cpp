#include "main.h"

#define PIXEL_PER_CALL 5
#define MAX_PIXEL_DISTANCE 30

Point_Animation::Point_Animation(int x_start, int y_start, int points_added)
{
	//obivous...
	this->_discontinue = 0;
	this->points_added = points_added;
	
	//yup
	this->x = x_start;
	this->y = y_start;
	this->y_end = y_start - MAX_PIXEL_DISTANCE;
	
	//create the text to be displayed
	this->create_text_surface();
}

Point_Animation::~Point_Animation()
{
	
}

void Point_Animation::display_next_image()
{
	//draw
	main_game->draw_noflip(this->x, this->y, this->text_surface);
	
	//set next point
	this->y -= PIXEL_PER_CALL;
	
	//check if we're done...
	if(this->y < this->y_end)
		this->_discontinue = 1;
}

int Point_Animation::EOL()
{
	if(this->_discontinue) return 1;
	return 0;
}

void Point_Animation::discontinue()
{
	this->_discontinue = 1;
}

void Point_Animation::create_text_surface()
{
	char pnt_txt[30];
	
	sprintf(pnt_txt, "+%d", this->points_added);
	
	this->text_surface = main_game->make_text(pnt_txt,32,0,0,0);
}
