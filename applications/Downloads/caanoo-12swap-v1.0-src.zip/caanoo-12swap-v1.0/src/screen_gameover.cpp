#include "main.h"

//our very own "screen number"
int screen_gameover;

//our button numbers...
int screen_gameover_button_playagain;

void load_screen_gameover()
{
	char score_text[50];
	
	//display the score you ended with...
	sprintf(score_text,"%d",points);
	main_game->draw_text(305,305,score_text,30);
}

void button_screen_gameover(int i)
{
	//go back to playchoice screen
	if(i == screen_gameover_button_playagain)
		main_game->load_screen(screen_playchoice);
}
