12swap

REQUIRED LIBRARIES:
SDL - http://www.libsdl.org/
SDL_ttf - http://www.libsdl.org/projects/SDL_ttf/

ORIGINS:
This game was originally developed by the 12 swap company. The game was originally developed in flash and can be easily found on many flash game websites through any search engine. This version of the game however was developed by Nighsoft and financed by all4fun. To my knowledge both 12 swap and all4fun have disappeared.

LINUX:
Simply type in make while in the root 12swap folder, then ./12swap . If you have any problems please visit websites at the bottom of this file.

WINDOWS:
This is not the official windows distribution of this game, you can however compile it anyways but documentation on doing so I reserve for the windows distribution of this game.

MAC:
This game uses only 2 very well known mac compatible libraries, I do not own a mac to help support you though.

LOCATION and CONTACT:
http://www.nighsoft.com/
http://www.nighsoft.net/
freaknigh@hotmail.com


01/07/2011 : ported to caanoo by Zx-81
