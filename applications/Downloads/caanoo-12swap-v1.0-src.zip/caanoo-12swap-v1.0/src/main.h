#include <SDL/SDL.h>
#include <SDL/SDL_thread.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_audio.h>
#include <SDL/SDL_video.h>
#include <SDL/SDL_joystick.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/timeb.h>

//defines
#define SCREEN_MAX 20
#define BUTTON_MAX 100
#define SOUND_MAX 40
#define FACE_MAX 20
#define FACE_TEMPLATE_MAX 20
#define NORMAL_ANIM_MAX 64
#define DROP_ANIM_MAX 8
#define ROUND_ANIM_MAX 40
#define POINT_ANIM_MAX 12
#define ANIMATIONS_PER_SECOND 20
#define ANIMATIONS_INTERVAL 1.0 / ANIMATIONS_PER_SECOND
#define MAX_FONT_SIZE 60
#define PI 3.14159
#define IS_TRIAL 0

struct sound_sample 
{
	SDL_AudioSpec sound_info;
	Uint8 *data;
	Uint32 dpos;
	Uint32 dlen;
};

class Trial_Timer_Animation
{
	public:
		Trial_Timer_Animation();
		~Trial_Timer_Animation();
		
		void display_next_image();
		int EOL();
		void discontinue();
	private:
		int _discontinue;
		double end_time;
};

class Score_Disolve_Animation
{
	public:
		Score_Disolve_Animation();
		~Score_Disolve_Animation();
		
		void display_next_image();
		int EOL(); //end of line
		void discontinue();
	private:
		int _discontinue;
};

class Score_Animation
{
	public:
		Score_Animation(int current_score, int new_score);
		~Score_Animation();
		
		void display_next_image();
		int EOL(); //end of line
		void discontinue();
		
		void set_new_new_score(int new_score);
	private:
		int current_score, new_score;
		int score_inc;
		int ticker;
		int _discontinue;
};

class Point_Animation
{
	public:
		Point_Animation(int x_start, int y_start, int points_added);
		~Point_Animation();
		
		void display_next_image();
		int EOL(); //end of line
		void discontinue();
	private:
		int points_added;
		int x, y, y_end;
		SDL_Surface *text_surface;
		int _discontinue;
		
		void create_text_surface();
};

class Round_Animation
{
	public:
		Round_Animation(int round_num);
		~Round_Animation();
		
		void display_next_image();
		int EOL(); //end of line
		void discontinue();
	private:
		int round_num;
		SDL_Surface *text_surface;
		bool display_pause;
		bool is_returning;
		int ticker;
		int array_current;
		int _discontinue;
		
		void create_text_surface();
};

class Swap_Animation
{
	public:
		Swap_Animation(int i, int k, int i2, int k2, bool is_good);
		~Swap_Animation();
		
		void display_next_image();
		int EOL(); //end of line
		void discontinue();
		
		bool is_swapping_index(int index);
	private:
		int index1, index2;
		int i1, k1, i2, k2;
		int x1, y1, x2, y2;
		int x1_end, y1_end, x2_end, y2_end;
		int face1, face2;
		bool is_good_swap;
		bool is_returning;
		int array_current;
		SDL_Rect clear_area;
		SDL_Surface *back_round;
		int _discontinue;
};

class Selector_Animation
{
	public:
		Selector_Animation(int i);
		~Selector_Animation();
		
		void display_next_image();
		int EOL(); //end of line
		void discontinue();
	private:
		int i, k;
		int x, y;
		SDL_Surface *back_round;
		double ticker;
		int _discontinue;
		
		void create_backround();
};

class Normal_Animation
{
	public:
		Normal_Animation(int x_center, int y_center, SDL_Surface **array_image);
		~Normal_Animation();
		
		void display_next_image();
		int EOL(); //end of line
		void discontinue();
	private:
		int x_center, y_center;
		SDL_Surface **array_image;
		int array_current;
		double ticker;
		int _discontinue;
	
};

class Drop_Animation
{
	public:
		Drop_Animation(int i, int to, int from = -1);
		~Drop_Animation();
		
		void display_next_image();
		int EOL(); //end of line
		void discontinue();
		
		int get_to();
	private:
		int i; //the row number
		int to; // how far it goes down
		int from; //from where it starts
		int x, end_y;
		int final_resting_place[8], current_placement[8];
		int discontinue_anim;
		SDL_Rect cover_crop_area;
		
		void set_random_displacements();
};

class Screen_Button
{
	public:
		Screen_Button();
		~Screen_Button();
		
		void load_mouse_over_img(char *filename);
		void load_mouse_off_img(char *filename);
		void override_boundaries(int x, int y, int w = 0, int h = 0);
		
		int within_boundary(int x, int y);
		int test_for_draw(int x, int y);
		
		int is_active();
		void activate();
		void deactivate();
	private:
		SDL_Surface *mouse_over;
		SDL_Surface *mouse_off;
		int _is_active;
		int last_drawn;
		int x, y;
		int w, h;
};

//classes
class Screen_Layout
{
	public:
		Screen_Layout();
		~Screen_Layout();
		
		void show();
		
		void do_mousepress(int x, int y);
		void do_mousemovement(int x, int y);
		
		void load_backround(char *backround_filename);
		SDL_Surface *get_backround();
		
		void set_load_func(void (*func_ptr)(void));
		void set_buttonpress_func(void (*func_ptr)(int i));
		void set_buttonover_func(void (*func_ptr)(int i, bool is_overtop));
		
		int make_button(int x, int y, char *button_filename = 0, int w = 0, int h = 0);
		Screen_Button *get_button(int button_num);
		
		void start_animator_engine();
		void stop_animator_engine();
		void start_animation(int index, SDL_Surface *animation_array[]);
		void start_drop_row_animation(int i, int to, int from = -1);
		void start_selector_animation(int index);
		void start_swap_animation(int i, int k, int i2, int k2, bool is_good);
		void start_round_animation(int round_num);
		void start_point_animation(int i, int k, int points_added);
		void start_score_animation(int current_score, int new_score);
		void start_score_disolve_animation();
		void start_trial_timer_animation();
		bool doing_score_animation();
		bool doing_trial_timer_animation();
		void stop_selector_animation();
		
		void pause_while_drop();
				
	private:
		int button_max;
		Screen_Button *button[BUTTON_MAX];
		SDL_Surface *backround;
		SDL_Thread *animator_thread;
		int animator_run;
		Normal_Animation *anim_norm[NORMAL_ANIM_MAX];
		Drop_Animation *anim_drop[DROP_ANIM_MAX];
		Selector_Animation *anim_selector;
		Swap_Animation *anim_swap;
		Round_Animation *anim_round;
		Score_Animation *anim_score;
		Score_Disolve_Animation *anim_score_disolve;
		Trial_Timer_Animation *anim_trail_timer;
		Point_Animation *anim_point[POINT_ANIM_MAX];
		
		void (*func_load)(void);
		void (*func_buttonpress)(int i);
		void (*func_buttonover)(int i, bool is_overtop);
		
		friend int animator_func(void *nothing);
};

class Swap_Game
{
	public:
		Swap_Game();
		~Swap_Game();
		
		int make_screen(char *backround_filename);
		Screen_Layout *get_screen(int screen_num);
		Screen_Layout *get_current_screen();
 		void load_screen(int screen_num);
		void fade_screen(int screen_num);
		
		int make_sound(char *filename);
		void play_sound(int sound_num);
		
		void draw(int x, int y, SDL_Surface *image, int crop_x = 0, int crop_y = 0, int crop_w = 0, int crop_h = 0);
		void draw_noflip(int x, int y, SDL_Surface *image, int crop_x = 0, int crop_y = 0, int crop_w = 0, int crop_h = 0);
		void draw_noflip_layered(int x, int y, SDL_Surface *image, int crop_x = 0, int crop_y = 0, int crop_w = 0, int crop_h = 0);
		void draw_text(int x, int y, char *text, int size = 16, bool center_w = true, bool center_h = true, int r_backround = -1, int g_backround = -1, int b_backround = -1);
		void draw_text_noflip(int x, int y, char *text, int size = 16, bool center_w = true, bool center_h = true, int r_backround = -1, int g_backround = -1, int b_backround = -1);
		void draw_box(int x, int y, int w, int h, int r, int g, int b, int a = 0);
		void draw_box_noflip(int x, int y, int w, int h, int r, int g, int b, int a = 0);
		SDL_Surface *make_text(char *text, int size = 16, int r = 0, int g = 0, int b = 0);
		void clear_screen_layered();
		void backup_screen();
		void unbackup_screen();
		void flip_screen();
		void flip_screen_layered();
		
		double current_time();
		
		void run_game();
	private:
		int screen_max;
		int sound_max;
		int screen_visible;
		Screen_Layout *form[SCREEN_MAX];
		SDL_Surface *real_screen;
		SDL_Surface *main_screen;
		SDL_Surface *main_screen_temp;
		SDL_Surface *layered_screen;
		TTF_Font *ttf_font[MAX_FONT_SIZE];
		sound_sample game_sound[SOUND_MAX];
		bool screen_flipping;
		bool screen_drawing;
		int time_offset;
		
		int init_sdl();
		int init_ttf();
		int init_audio();
		void init_time();
		void init_randomizer();
		void handle_events();
		void load_font(int size);
		
		void create_second_screen_layer();
		void create_backup_screen_layer();
		
		void draw_mutux(SDL_Surface *src, SDL_Rect *crop, SDL_Surface *dest, SDL_Rect *dest_loc);
		
		friend void mixaudio(void *unused, Uint8 *stream, int len);
};

//publics
extern Swap_Game *main_game;
extern int playchoice_option;
extern int sounds_on;
extern int game_paused;
extern int face_max;
extern int round_number;
extern int timer_points;
extern int timer_old_points;
extern int timer_win_points;
extern int points;
extern int win_points;
extern int old_win_points;
extern int board[8][8];

//screens
extern int screen_intro;
extern int screen_intro2;
extern int screen_game;
extern int screen_gameover;
extern int screen_instructions;
extern int screen_playchoice;

//screen buttons
extern int screen_instructions_button_play;
extern int screen_playchoice_button_play;
extern int screen_playchoice_button_moves;
extern int screen_playchoice_button_time;
extern int screen_game_button_pause;
extern int screen_game_button_sound_off;
extern int screen_game_button_new_game;
extern int screen_game_button_hint;
extern int screen_game_button_resume;
extern int screen_game_button_sound_on;
extern int screen_game_button_boardstart;
extern int screen_gameover_button_playagain;

//screen functions
extern void load_screen_intro();
extern void load_screen_intro2();
extern void load_screen_playchoice();
extern void load_screen_game();
extern void load_screen_gameover();
extern void button_screen_instructions(int i);
extern void button_screen_playchoice(int i);
extern void button_screen_game(int i);
extern void button_screen_gameover(int i);
extern void motion_screen_game(int i, bool is_overtop);

//game sounds
extern int sound_roundstart;
extern int sound_badchoice;
extern int sound_goodchoice;

//screen other images
extern SDL_Surface *playchoice_select_img;
extern SDL_Surface *playchoice_select_moves_img;
extern SDL_Surface *playchoice_select_time_img;
extern SDL_Surface *game_face[FACE_MAX];
extern SDL_Surface *game_face_blink[FACE_MAX][FACE_TEMPLATE_MAX];
extern SDL_Surface *game_face_hint[FACE_MAX][FACE_TEMPLATE_MAX];
extern SDL_Surface *game_face_sad[FACE_MAX][FACE_TEMPLATE_MAX];
extern SDL_Surface *game_round_img[ROUND_ANIM_MAX];
extern SDL_Surface *face_template;
extern SDL_Surface *dropcover;
extern SDL_Surface *game_progress_bar;
extern SDL_Surface *game_progress_bar_empty;
extern SDL_Surface *game_selector;

//our good friends...
extern int animator_func(void *nothing);
extern void mixaudio(void *unused, Uint8 *stream, int len);

//other functions i wasn't able to avoid...
extern void set_old_points();

