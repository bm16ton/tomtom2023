/** @file rev.h declaration of OpenDune revision dependant variables */

#ifndef REV_H
#define REV_H

extern const char g_opendune_revision[];
extern const char g_opendune_build_date[];
extern const uint8 g_opendune_revision_modified;

#endif /* REV_H */
