Third party components used:


===============================================================================
RESOURCES
===============================================================================


===============================================================================
Some icons are from FatCow Free Icons set "Farm-Fresh Web Icons""

Terms of Use

These icon sets are licensed under a Creative Commons Attribution 3.0 License. 
This means you can freely use these icons for any purpose, private and commercial, 
including online services, templates, themes and software.
However, you should include a link to this page in your credits.
The icons may not be resold, sub-licensed, rented, transferred or otherwise made 
available for use.
Please link to this page on fatcow.com if you would like to spread the word.

http://www.fatcow.com/free-icons
===============================================================================
