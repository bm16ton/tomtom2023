#include "main.h"

#define PIXEL_PER_CALL 15
#define ANIMATION_PER_CALL 1

Swap_Animation::Swap_Animation(int i1, int k1, int i2, int k2, bool is_good)
{
	const int x_start = 205;
	const int y_start = 60;
	const int y_spacer = 47;
	const int x_spacer = 50;
	
	//obivous i hope
	this->_discontinue = 0;
	this->array_current = 0;
	
	//set all the simple stuff
	this->i1 = i1;
	this->k1 = k1;
	this->i2 = i2;
	this->k2 = k2;
	this->is_good_swap = is_good;
	
	//set us on the begining run, even if there is no return ever
	this->is_returning = false;
	
	//set faces
	this->face1 = board[i2][k2];
	this->face2 = board[i1][k1];
	
	//set indexes
	this->index1 = (this->i1 * 8) + this->k1;
	this->index2 = (this->i2 * 8) + this->k2;
	
	//set starting locs and ending locs
	this->x1 = x_start + (this->i1 * x_spacer);
	this->y1 = y_start + (this->k1 * y_spacer);
	this->x2 = x_start + (this->i2 * x_spacer);
	this->y2 = y_start + (this->k2 * y_spacer);
	this->x1_end = this->x2;
	this->y1_end = this->y2;
	this->x2_end = this->x1;
	this->y2_end = this->y1;
	
	//set the crop area.
	if(this->x1 <= this->x2) this->clear_area.x = this->x1;
	if(this->x1 >= this->x2) this->clear_area.x = this->x2;
	if(this->y1 <= this->y2) this->clear_area.y = this->y1;
	if(this->y1 >= this->y2) this->clear_area.y = this->y2;
	if(this->x1 == this->x2)
	{
		this->clear_area.w = 35;
		this->clear_area.h = 35 + y_spacer;
	}
	else
	{
		this->clear_area.w = 35 + x_spacer;
		this->clear_area.h = 35;
	}
}

Swap_Animation::~Swap_Animation()
{
	
}

void Swap_Animation::display_next_image()
{
	int x_dir1, y_dir1, x_dir2, y_dir2;
	//wipe out area
	main_game->draw_noflip(this->clear_area.x, this->clear_area.y, main_game->get_screen(screen_game)->get_backround(), this->clear_area.x, this->clear_area.y, this->clear_area.w, this->clear_area.h);
	
	//check if that was our last display...
	if(this->x1 == this->x1_end && this->y1 == this->y1_end)
		if(this->is_good_swap || (!this->is_good_swap && this->is_returning))
	{
		//draw that happy face...
		main_game->draw_noflip(this->x1, this->y1, game_face[this->face1]);
		main_game->draw_noflip(this->x2, this->y2, game_face[this->face2]);
		
		this->_discontinue = 1;
		return;
	}
	
	//draw in new
	if(!this->is_returning)
	{
		main_game->draw_noflip(this->x1, this->y1, game_face[this->face1]);
		main_game->draw_noflip(this->x2, this->y2, game_face[this->face2]);
	}
	else
	{
		//do some security checks...
		if(!game_face_sad[this->face1][this->array_current])
		{
			//check if we have any at all....
			if(!this->array_current)
			{
				main_game->draw_noflip(this->x1, this->y1, game_face[this->face1]);
				main_game->draw_noflip(this->x2, this->y2, game_face[this->face2]);
			}
			else
			{
				//display the last one avaible then
				main_game->draw_noflip(this->x1, this->y1, game_face_sad[this->face1][this->array_current - 1]);
				main_game->draw_noflip(this->x2, this->y2, game_face_sad[this->face2][this->array_current - 1]);
			}
		}
		else
		{
			main_game->draw_noflip(this->x1, this->y1, game_face_sad[this->face1][this->array_current]);
			main_game->draw_noflip(this->x2, this->y2, game_face_sad[this->face2][this->array_current]);
			
			this->array_current += ANIMATION_PER_CALL;
		}
	}
	
	//set direction...
	if(this->x1 == this->x1_end) x_dir1 = 0;
	if(this->x1 > this->x1_end) x_dir1 = -1;
	if(this->x1 < this->x1_end) x_dir1 = 1;
	
	if(this->y1 == this->y1_end) y_dir1 = 0;
	if(this->y1 > this->y1_end) y_dir1 = -1;
	if(this->y1 < this->y1_end) y_dir1 = 1;
	
	x_dir2 = x_dir1 * -1;
	y_dir2 = y_dir1 * -1;
	
	this->x1 += PIXEL_PER_CALL * x_dir1;
	this->y1 += PIXEL_PER_CALL * y_dir1;
	this->x2 += PIXEL_PER_CALL * x_dir2;
	this->y2 += PIXEL_PER_CALL * y_dir2;
	
	//over step boundaries?
	if(x_dir1 > 0 && this->x1 > this->x1_end) this->x1 = this->x1_end;
	if(x_dir1 < 0 && this->x1 < this->x1_end) this->x1 = this->x1_end;
	if(y_dir1 > 0 && this->y1 > this->y1_end) this->y1 = this->y1_end;
	if(y_dir1 < 0 && this->y1 < this->y1_end) this->y1 = this->y1_end;
	
	if(x_dir2 > 0 && this->x2 > this->x2_end) this->x2 = this->x2_end;
	if(x_dir2 < 0 && this->x2 < this->x2_end) this->x2 = this->x2_end;
	if(y_dir2 > 0 && this->y2 > this->y2_end) this->y2 = this->y2_end;
	if(y_dir2 < 0 && this->y2 < this->y2_end) this->y2 = this->y2_end;
	
	//check if we need to turn it around
	if(this->x1 == this->x1_end && this->y1 == this->y1_end)
	{
		if(!this->is_good_swap)
		{
			if(!this->is_returning)
			{
				int temp_x;
				int temp_y;
				this->is_returning = 1;
				
				//switch ends
				temp_x = this->x1_end;
				temp_y = this->y1_end;
				this->x1_end = this->x2_end;
				this->y1_end = this->y2_end;
				this->x2_end = temp_x;
				this->y2_end = temp_y;
				
				//and the nope sound
				main_game->play_sound(sound_badchoice);
			}
		}
		else
		{
			//and the good sound
			main_game->play_sound(sound_goodchoice);
		}
	}
}

int Swap_Animation::EOL()
{
	//this animation is done thoroughly through the discontinue.
	if(this->_discontinue) return 1;
	return 0;
}

void Swap_Animation::discontinue()
{
	this->_discontinue = 1;
}

bool Swap_Animation::is_swapping_index(int index)
{
	return (index == this->index1 || index == this->index2);
}
