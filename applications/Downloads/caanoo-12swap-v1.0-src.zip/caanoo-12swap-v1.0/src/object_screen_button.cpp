#include "main.h"

Screen_Button::Screen_Button()
{
	this->x = 0;
	this->y = 0;
	this->w = 0;
	this->h = 0;
	
	this->mouse_off = 0;
	this->mouse_over = 0;
	this->last_drawn = 0;
	this->_is_active = 1;
}

Screen_Button::~Screen_Button()
{
	
}

void Screen_Button::load_mouse_over_img(char *filename)
{
	this->mouse_over = SDL_LoadBMP(filename);
	
	if(!this->mouse_over) return;
	
	SDL_SetColorKey(this->mouse_over, SDL_SRCCOLORKEY, SDL_MapRGB(this->mouse_over->format, 255,255,255));
}

void Screen_Button::load_mouse_off_img(char *filename)
{
	this->mouse_off = SDL_LoadBMP(filename);
	
	if(!this->mouse_off) return;
	
	SDL_SetColorKey(this->mouse_off, SDL_SRCCOLORKEY, SDL_MapRGB(this->mouse_off->format, 255,255,255));
	
	if(!this->w) this->w = this->mouse_off->w;
	if(!this->h) this->h = this->mouse_off->h;
}

void Screen_Button::override_boundaries(int x, int y, int w, int h)
{
	this->x = x;
	this->y = y;
	
	if(w) this->w = w;
	if(h) this->h = h;
}

int Screen_Button::within_boundary(int x, int y)
{
	if(x < this->x) return 0;
	if(x > this->x + this->w) return 0;
	if(y < this->y) return 0;
	if(y > this->y + this->h) return 0;
	
	//passed the test.
	return 1;
}

int Screen_Button::test_for_draw(int x, int y)
{
	int is_over;
	
	is_over = this->within_boundary(x,y);
	
	if(this->last_drawn) // was the last drawn image, the mouse over one?
	{
		//check to see if we need to draw the mouse off image
		if(!is_over)
		{
			this->last_drawn = 0;
			if(this->mouse_off)
				main_game->draw(this->x,this->y,this->mouse_off);
			return 1;
		}
	}
	else //it wasnt?
	{
		//check to see if we need to draw the mouse over image
		if(is_over)
		{
			this->last_drawn = 1;
			if(this->mouse_over)
				main_game->draw(this->x,this->y,this->mouse_over);
			return 2; //the one case where we return "yes, this is the first case where it is over the button"
		}
	}
	
	return 0;
}

int Screen_Button::is_active()
{
	return this->_is_active;
}

void Screen_Button::activate()
{
	this->_is_active = 1;
	
	//draw the off image if it exists
	if(!this->mouse_off) return;
		
	//also set the last drawn
	this->last_drawn = 0;
	main_game->draw(this->x,this->y,this->mouse_off);
}

void Screen_Button::deactivate()
{
	this->_is_active = 0;
}

