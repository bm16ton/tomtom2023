#include "main.h"

//our very own "screen number"
int screen_instructions;

//our button numbers...
int screen_instructions_button_play;

void button_screen_instructions(int i)
{
	if(i == screen_instructions_button_play)
	{
		main_game->load_screen(screen_playchoice);
	}
}
