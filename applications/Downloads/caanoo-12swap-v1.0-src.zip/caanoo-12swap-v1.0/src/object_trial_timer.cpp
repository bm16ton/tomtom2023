#include "main.h"

#define SECONDS_TILL_END 80

Trial_Timer_Animation::Trial_Timer_Animation()
{
	this->_discontinue = 0;
	this->end_time = main_game->current_time() + SECONDS_TILL_END;
}

Trial_Timer_Animation::~Trial_Timer_Animation()
{
	
}

void Trial_Timer_Animation::display_next_image()
{
	int minutes_till, seconds_till;
	double time_left;
	char timer_str[50];
	
	//setup time left
	time_left = this->end_time - main_game->current_time();
	
	if(time_left < 0)
	{
		this->_discontinue = 1;
		return;
	}
	
	//setup these variables for ease
	minutes_till = (int)(time_left / 60);
	seconds_till = (int)time_left % 60;
	
	//setup the string
	if(seconds_till > 9)
		sprintf(timer_str,"%d:%d", minutes_till, seconds_till);
	else
		sprintf(timer_str,"%d:0%d", minutes_till, seconds_till);
	
	//clear the backround
	main_game->draw_noflip(545,2,main_game->get_screen(screen_game)->get_backround(),545,2,90,40);
	
	//display that time
	main_game->draw_text_noflip(545,2,timer_str,40,false,false);
}

int Trial_Timer_Animation::EOL()
{
	return this->_discontinue;
}

void Trial_Timer_Animation::discontinue()
{
	this->_discontinue = 1;
}
