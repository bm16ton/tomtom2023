#include "main.h"

#define PAUSE_ANIM_CALLS 10

#define X_CENTER 398
#define Y_CENTER 242

Round_Animation::Round_Animation(int round_num)
{
	//obivous
	this->_discontinue = 0;
	this->ticker = 0;
	this->array_current = 0;
	this->display_pause = false;
	this->is_returning = false;
	
	//simple
	this->round_num = round_num;
	
	//get 'er ready
	this->create_text_surface();
}

Round_Animation::~Round_Animation()
{
	SDL_FreeSurface(this->text_surface);
}

void Round_Animation::display_next_image()
{
	//do the increase
	if(!this->display_pause)
	{
		if(this->is_returning)
			this->array_current--;
		else
			this->array_current++;
		
		//now what to display..
		if(this->array_current > 0 && game_round_img[this->array_current])
		{
			main_game->draw_noflip(X_CENTER - (game_round_img[this->array_current]->w / 2),Y_CENTER - (game_round_img[this->array_current]->h / 2),game_round_img[this->array_current]);
			
			return;
		}
		else
		{
			if(!this->is_returning)
			{
				this->is_returning = true;
				this->display_pause = true;
				this->array_current--;
			}
			else
			{
				this->_discontinue = 1;
				return;
			}
		}
	}
	
	//display the round name
	if(this->array_current > 0 && game_round_img[this->array_current])
		main_game->draw_noflip(X_CENTER - (game_round_img[this->array_current]->w / 2),Y_CENTER - (game_round_img[this->array_current]->h / 2),game_round_img[this->array_current]);
		
	//draw on the text
	main_game->draw_noflip(X_CENTER - (this->text_surface->w / 2),Y_CENTER - (this->text_surface->h / 2),this->text_surface);
	
	//do the ticker
	this->ticker++;
	if(this->ticker >= PAUSE_ANIM_CALLS)
		this->display_pause = false;
}

int Round_Animation::EOL()
{
	if(this->_discontinue) return 1;
	return 0;
}

void Round_Animation::discontinue()
{
	this->_discontinue = 1;
}

void Round_Animation::create_text_surface()
{
	char round_name[30];
	
	sprintf(round_name, "Round%d", this->round_num);
	
	this->text_surface = main_game->make_text(round_name,40,255,255,254);
}
