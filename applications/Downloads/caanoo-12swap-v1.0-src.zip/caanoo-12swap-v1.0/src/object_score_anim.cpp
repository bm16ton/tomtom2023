#include "main.h"

#define TICK_MAX 11

Score_Animation::Score_Animation(int current_score, int new_score)
{
	//obivious
	this->_discontinue = 0;
	
	//easy
	this->current_score = current_score;
	
	//wrap it up
	this->set_new_new_score(new_score);
}

Score_Animation::~Score_Animation()
{
	
}

void Score_Animation::display_next_image()
{
	char score_text[50];
	
	//do the inc
	this->current_score += this->score_inc;
	timer_old_points += this->score_inc;
	
	//check
	if(this->current_score > this->new_score)
		this->current_score = this->new_score;
	
	if(timer_old_points > timer_points)
		timer_old_points = timer_points;
	
	//draw monkey
	sprintf(score_text,"%d",this->current_score);
	main_game->draw_text_noflip(85,233,score_text,16,true,true,255,255,203);

	//draw progress bar if need be
	if(playchoice_option)
	{
		if(this->current_score > old_win_points)
		{
			main_game->draw_noflip(192, 453, game_progress_bar, 0, 0, (int)((game_progress_bar->w * (this->current_score - old_win_points)) / (win_points - old_win_points)), game_progress_bar->h);
		}
		else
		{
			//clear it out monkey...
			main_game->draw_noflip(192, 453, game_progress_bar_empty);
		}
		
		//check for done
		if(this->current_score == this->new_score)
		{
			this->_discontinue = 1;
			//wish i could have avoided this bad practice...
			set_old_points();
		}
	}
	else
	{
		if(timer_points > timer_old_points)
		{
			main_game->draw_noflip(192, 453, game_progress_bar, 0, 0, (int)(game_progress_bar->w * (1.0 * timer_old_points / timer_win_points)), game_progress_bar->h);
		}
		else
		{
			this->_discontinue = 1;
			
			set_old_points();
		}
		
		if(timer_points >= timer_win_points)
		{
			//clear it out monkey...
			main_game->draw_noflip(192, 453, game_progress_bar_empty);
		}
	}
}

int Score_Animation::EOL()
{
	return this->_discontinue;
}

void Score_Animation::discontinue()
{
	this->_discontinue = 1;
}

void Score_Animation::set_new_new_score(int new_score)
{
	//things that need set...
	this->new_score = new_score;
	
	//setup
	if(playchoice_option)
		this->score_inc = (new_score - this->current_score) / TICK_MAX;
	else
		this->score_inc = (timer_points - timer_old_points) / TICK_MAX;
	
	if(!this->score_inc)
		this->score_inc = 1;
}

