#include "main.h"

//our very own "screen number"
int screen_intro2;

//our button numbers...

void load_screen_intro2()
{
	SDL_Delay(3000);
	main_game->fade_screen(screen_instructions);
}
