#include "main.h"

#define DISOLVE_PER_CALL 1

Score_Disolve_Animation::Score_Disolve_Animation()
{
	//obivious
	this->_discontinue = 0;
}

Score_Disolve_Animation::~Score_Disolve_Animation()
{

}

void Score_Disolve_Animation::display_next_image()
{
	timer_points -= DISOLVE_PER_CALL;
	timer_old_points -= DISOLVE_PER_CALL;
	
	//check for win or lose
	if(timer_points < 0)
	{
		this->_discontinue = 1;
		return;
	}
	
	//clear
	main_game->draw_noflip(192, 453, game_progress_bar_empty);
	
	//draw new
	main_game->draw_noflip(192, 453, game_progress_bar, 0, 0, (int)(game_progress_bar->w * (1.0 * timer_points / timer_win_points)), game_progress_bar->h);
}

int Score_Disolve_Animation::EOL()
{
	return this->_discontinue;
}

void Score_Disolve_Animation::discontinue()
{
	this->_discontinue = 1;
}
