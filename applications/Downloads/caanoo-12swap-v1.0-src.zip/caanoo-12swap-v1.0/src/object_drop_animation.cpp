#include "main.h"

#define PIXEL_PER_MOVE 40
#define MAX_PLACEMENT_DIFFERENCE 200

Drop_Animation::Drop_Animation(int i, int to, int from)
{
	//set some stuff
	this->discontinue_anim = 0;
	this->i = i;
	this->to = to;
	this->from = from;

	//make their places
	this->set_random_displacements();
}

Drop_Animation::~Drop_Animation()
{
	
}

void Drop_Animation::display_next_image()
{
	int i;
	
	//clear out the grounds
	main_game->draw_noflip(this->x,0, main_game->get_screen(screen_game)->get_backround(),this->x,0,35,this->end_y + 35);
	
	//draw in what needs to be in
	for(i=0;i<=this->to;i++)
		if(this->current_placement[i] <= this->final_resting_place[i])
	{
		//move the fool
		this->current_placement[i] += PIXEL_PER_MOVE;
		
		//overbounds?
		if(this->current_placement[i] >= this->final_resting_place[i])
			this->current_placement[i] = this->final_resting_place[i];
		
		//draw that beauty
		main_game->draw_noflip(this->x, this->current_placement[i], game_face[board[this->i][i]]);
	}
	
	//draw the cover
	main_game->draw_noflip(203,0,dropcover);
}

int Drop_Animation::EOL()
{
	if(this->current_placement[0] >= this->final_resting_place[0]) return 1;
	if(this->discontinue_anim) return 1;
	return 0;
}

void Drop_Animation::set_random_displacements()
{
	int i;
	int diff;
	const int x_start = 205;
	const int y_start = 60;
	const int y_spacer = 47;
	const int x_spacer = 50;
	
	diff = this->to - this->from;
	
	//set the boundaries
	this->end_y = y_start + (this->to * y_spacer);
	this->x = x_start + (this->i * x_spacer);
	

	//do the first one manualy
	i=this->to;
	this->final_resting_place[i] = this->end_y;
	if(i - diff < 0)
		this->current_placement[i] = 60 - (rand() % 50);
	else
		this->current_placement[i] = y_start + ((i - diff) * y_spacer);
	
	
	for(i--;i>=0;i--)
	{
		//set its ending location
		this->final_resting_place[i] = y_start + (i * y_spacer);
		
		//set its starting location
		if(i - diff < 0)
			this->current_placement[i] = this->current_placement[i+1] - ((rand() % MAX_PLACEMENT_DIFFERENCE) + y_spacer + 1);
		else
			this->current_placement[i] = y_start + ((i - diff) * y_spacer);
	}
}

void Drop_Animation::discontinue()
{
	this->discontinue_anim = 1;
}

int Drop_Animation::get_to()
{
	return this->to;
}
