#include "main.h"

Swap_Game::Swap_Game()
{
	this->main_screen = 0;
	this->main_screen_temp = 0;
	this->layered_screen = 0;
	this->screen_max = 0;
	this->sound_max = 0;
	this->screen_visible = -1;
	this->screen_flipping = false;
	this->screen_drawing = false;
	
	this->init_sdl();
	this->init_ttf();
	this->init_audio();
	this->init_time();
	this->init_randomizer();
}

Swap_Game::~Swap_Game()
{
	
}

void Swap_Game::create_second_screen_layer()
{
	Uint32 rmask, gmask, bmask, amask;
	
	//gotta have a screen to model it off of...
	if(!this->main_screen) return;

  rmask = main_screen->format->Rmask;
  gmask = main_screen->format->Gmask;
  bmask = main_screen->format->Bmask;
  amask = main_screen->format->Amask;
  int num_bits = main_screen->format->BitsPerPixel;
	
	//make the surface
	this->layered_screen = SDL_CreateRGBSurface(SDL_HWSURFACE | SDL_SRCCOLORKEY | SDL_SRCALPHA, this->main_screen->w, this->main_screen->h, num_bits, rmask, gmask, bmask, amask);
			
	//make it transparent
	SDL_SetColorKey(this->layered_screen, SDL_SRCCOLORKEY,  SDL_MapRGB(this->layered_screen->format, 0, 0, 0));
	
	//you will also need this....
	if(!this->main_screen_temp)
		this->create_backup_screen_layer();
}

void Swap_Game::create_backup_screen_layer()
{
	Uint32 rmask, gmask, bmask, amask;
	
	//gotta have a screen to model it off of...
	if(!this->main_screen) return;
	
  rmask = main_screen->format->Rmask;
  gmask = main_screen->format->Gmask;
  bmask = main_screen->format->Bmask;
  amask = main_screen->format->Amask;
  int num_bits = main_screen->format->BitsPerPixel;

  //make this swaping surface because it will be needed...
  this->main_screen_temp = SDL_CreateRGBSurface(SDL_HWSURFACE |
         SDL_SRCCOLORKEY, this->main_screen->w, this->main_screen->h, num_bits, rmask, gmask, bmask, amask);
	SDL_SetAlpha(this->main_screen_temp,SDL_RLEACCEL|SDL_SRCALPHA,255);
}

int Swap_Game::make_screen(char *backround_filename)
{
	int i;
	
	if(this->screen_max >= SCREEN_MAX) return -1;
	
	i = this->screen_max;
	
	//load the form
	this->form[i] = new Screen_Layout();
	this->form[i]->load_backround(backround_filename);
	
	//add to our max
	this->screen_max++;
	
	//return the screen num
	return i++;
}

Screen_Layout *Swap_Game::get_screen(int screen_num)
{
	//check if valid
	if(screen_num < 0) return 0;
	if(screen_num >= this->screen_max) return 0;

	//do code
	return this->form[screen_num];
}

Screen_Layout *Swap_Game::get_current_screen()
{
	if(this->screen_visible != -1)
		return this->form[this->screen_visible];
	else
		return NULL;
}

void Swap_Game::load_screen(int screen_num)
{
	//check if valid
	if(screen_num < -1) return;
	if(screen_num >= this->screen_max) return;
	
	//turn off current screen's animator...
	if(this->screen_visible != -1)
		this->form[this->screen_visible]->stop_animator_engine();

	//remind our game what screen is visible
	this->screen_visible = screen_num;
	
	//do code
	this->form[screen_num]->show();
}

void Swap_Game::fade_screen(int screen_num)
{
	const double fade_time = 3;
	const int delay_m = 40;
	const int tick_max = (int)((fade_time * 1000) / delay_m);
	const int alpha_tick = 255 / tick_max;
	int i;
	
	//check if valid
	if(screen_num < -1) return;
	if(screen_num >= this->screen_max) return;
	
	//turn off current screen's animator...
	if(this->screen_visible != -1)
		this->form[this->screen_visible]->stop_animator_engine();

	//make no screen visible during the fading
	this->screen_visible = -1;
	
	//fade into...
	for(i=0;i<=tick_max / 2;i++)
	{
		//set new alpha
		SDL_SetAlpha(this->form[screen_num]->get_backround(),SDL_RLEACCEL|SDL_SRCALPHA,(alpha_tick + 1) * i);
		this->draw(0,0,this->form[screen_num]->get_backround());
		SDL_Delay(delay_m);
	}
	SDL_SetAlpha(this->form[screen_num]->get_backround(),SDL_RLEACCEL|SDL_SRCALPHA,255);

	//remind our game what screen is visible
	this->screen_visible = screen_num;
	
	//do code
	this->form[screen_num]->show();
}

void Swap_Game::draw(int x, int y, SDL_Surface *image, int crop_x, int crop_y, int crop_w, int crop_h)
{
	//use the other function to make less code of it all
	this->draw_noflip(x, y, image, crop_x, crop_y, crop_w, crop_h);
	
	this->flip_screen();
}

void Swap_Game::draw_noflip(int x, int y, SDL_Surface *image, int crop_x, int crop_y, int crop_w, int crop_h)
{
	SDL_Rect destination;
	SDL_Rect crop_area;
	
	//check if image is valid.
	if(!image) return;
	
	destination.x = x;
	destination.y = y;
	
	//do crop method or no?
	if(crop_x || crop_y || crop_w || crop_h)
	{
		crop_area.x = crop_x;
		crop_area.y = crop_y;
		crop_area.w = crop_w;
		crop_area.h = crop_h;
		
		this->draw_mutux(image, &crop_area, this->main_screen, &destination);
	}
	else //non crop method
	{
		this->draw_mutux(image, NULL, this->main_screen, &destination);
	}
}


void Swap_Game::draw_noflip_layered(int x, int y, SDL_Surface *image, int crop_x, int crop_y, int crop_w, int crop_h)
{
	SDL_Rect destination;
	SDL_Rect crop_area;
	
	//make it if it doesnt exist
	if(!this->layered_screen)
		this->create_second_screen_layer();
	
	//exit if it for some reason still doesnt exist
	if(!this->layered_screen) return;
	
	//now do like the romans...
	if(!image) return;
	
	destination.x = x;
	destination.y = y;
	
	//do crop method or no?
	if(crop_x || crop_y || crop_w || crop_h)
	{
		crop_area.x = crop_x;
		crop_area.y = crop_y;
		crop_area.w = crop_w;
		crop_area.h = crop_h;
		
		this->draw_mutux(image, &crop_area, this->layered_screen, &destination);
	}
	else //non crop method
	{
		this->draw_mutux(image, NULL, this->layered_screen, &destination);
	}
}

SDL_Surface *Swap_Game::make_text(char *text, int size, int r, int g, int b)
{
	SDL_Color textcolor;
	
	//set our color
	textcolor.r = r;
	textcolor.g = g;
	textcolor.b = b;
	textcolor.unused = 0;
	
	//load the font if needed
	if(!this->ttf_font[size])
		this->load_font(size);
	
	//exit if it still isnt loaded
	if(!this->ttf_font[size]) return 0;
	
	//make the surface
	return TTF_RenderText_Solid(ttf_font[size], text, textcolor);
}

void Swap_Game::run_game()
{
	//just this for now
	this->handle_events();
}

int Swap_Game::init_sdl()
{
	if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO|SDL_INIT_JOYSTICK) <0)
	{
		printf("error: could not load sdl\n");
		return 0;
	}
	
# ifdef CAANOO
  SDL_JoystickEventState(SDL_ENABLE);
  SDL_JoystickOpen(0);

	this->real_screen = SDL_SetVideoMode(320,240, 16, SDL_SWSURFACE);
	this->main_screen = SDL_CreateRGBSurface(SDL_SWSURFACE, 
                            640, 520,
                            this->real_screen->format->BitsPerPixel,
                            this->real_screen->format->Rmask,
                            this->real_screen->format->Gmask,
                            this->real_screen->format->Bmask, 
                            this->real_screen->format->Amask );
  SDL_ShowCursor(SDL_DISABLE);
# else
	this->main_screen = SDL_SetVideoMode(640,520,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	if (!this->main_screen)
	{
		printf("error: could not set screen for 640x520 32bit\n");
		return 0;
	}
# endif
	
	SDL_WM_SetCaption("12Swap", "12Swap");
	
	atexit(SDL_Quit);
	
	return 1;
}

int Swap_Game::init_ttf()
{
	int i;
	
	if( TTF_Init() <0)
	{
		printf("error: could not load sdl_ttf\n");
		return 0;
	}
	
	//clear all the fonts
	for(i=0;i<MAX_FONT_SIZE;i++)
		this->ttf_font[i] = 0;
}

void Swap_Game::load_font(int size)
{
	this->ttf_font[size] = TTF_OpenFont("graphics/fonts/arialbd.ttf",size);
}

void Swap_Game::draw_text(int x, int y, char *text, int size, bool center_w, bool center_h, int r_backround, int g_backround, int b_backround)
{
	this->draw_text_noflip(x, y, text, size, center_w, center_h, r_backround, g_backround, b_backround);
	
	this->flip_screen();
}

void Swap_Game::draw_text_noflip(int x, int y, char *text, int size, bool center_w, bool center_h, int r_backround, int g_backround, int b_backround)
{
	SDL_Surface *text_surface;
	SDL_Surface *back_surface;
	SDL_Color textcolor;
	SDL_Rect destination;
	Uint32 rmask, gmask, bmask, amask;
	
	//set our color
	textcolor.r = 0;
	textcolor.g = 0;
	textcolor.b = 0;
	textcolor.unused = 0;
	
	//do this...
	back_surface = 0;
	
	//load the font if needed
	if(!this->ttf_font[size])
		this->load_font(size);
	
	//exit if it still isnt loaded
	if(!this->ttf_font[size]) return;
	
	//make the surface
	text_surface = TTF_RenderText_Solid(ttf_font[size], text, textcolor);
	if(!text_surface) return;
	
		//make back surface if required
	if(r_backround != -1 || g_backround != -1 || b_backround != -1)
	{
    rmask = main_screen->format->Rmask;
    gmask = main_screen->format->Gmask;
    bmask = main_screen->format->Bmask;
    amask = main_screen->format->Amask;
    int num_bits = main_screen->format->BitsPerPixel;

		back_surface = SDL_CreateRGBSurface(SDL_HWSURFACE | SDL_SRCCOLORKEY, text_surface->w, text_surface->h, 
                    num_bits, rmask, gmask, bmask, amask);
		
		//dont waste our time
		if(back_surface)
		{
			//set the loc
			destination.x = 0;
			destination.y = 0;
			destination.w = text_surface->w;
			destination.h = text_surface->h;
			
			//fill it with that color
			SDL_FillRect(back_surface,&destination,SDL_MapRGB(back_surface->format, r_backround, g_backround, b_backround));
			
			//put text on this surface
			this->draw_mutux(text_surface, NULL, back_surface, &destination);
		}
	}
	
	//do the centering
	if(center_w)
		x -= text_surface->w / 2;
	if(center_h)
		y -= text_surface->h / 2;
	destination.x = x;
	destination.y = y;
	
	if(back_surface)
		this->draw_mutux(back_surface, NULL, this->main_screen, &destination);
	else //draw surface normaly
		this->draw_mutux(text_surface, NULL, this->main_screen, &destination);
}

void Swap_Game::draw_box(int x, int y, int w, int h, int r, int g, int b, int a)
{
	this->draw_box_noflip(x, y, w, h, r, g, b, a);
	
	this->flip_screen();
}

void Swap_Game::draw_box_noflip(int x, int y, int w, int h, int r, int g, int b, int a)
{
	SDL_Rect destination;
	
	//set some defaults...
	destination.x = x;
	destination.y = y;
	destination.w = w;
	destination.h = h;
	
	SDL_FillRect(this->main_screen,&destination,SDL_MapRGBA(this->main_screen->format, r,g,b,a));
}

#define CAANOO_A               (0)
#define CAANOO_X               (1)
#define CAANOO_B               (2)
#define CAANOO_Y               (3)
#define CAANOO_L               (4)
#define CAANOO_R               (5)
#define CAANOO_HOME            (6)        
#define CAANOO_HOLD            (7)
#define CAANOO_SELECT          (8)
#define CAANOO_START           (9)        
#define CAANOO_FIRE            (10)

#define CAANOO_UP              (11)
#define CAANOO_DOWN            (12)
#define CAANOO_LEFT            (13)
#define CAANOO_RIGHT           (14)
#define CAANOO_UPLEFT          (15)
#define CAANOO_UPRIGHT         (16)
#define CAANOO_DOWNLEFT        (17)
#define CAANOO_DOWNRIGHT       (18)

void Swap_Game::handle_events()
{
	SDL_Event event;
	int exitkey = 0;

	while(!exitkey && SDL_WaitEvent(&event))//SDL_PollEvent(&event))
		switch( event.type ) 
	{
# ifdef CAANOO
    case SDL_JOYBUTTONDOWN :
       {
         int button = event.jbutton.button;
         if (button == CAANOO_HOME) exitkey = 1;
       }
      break;
# endif
		case SDL_QUIT:
			exitkey = 1;
			break;
		case SDL_MOUSEBUTTONDOWN:
			if(this->screen_visible == -1) break;
			this->form[this->screen_visible]->do_mousepress(event.button.x,event.button.y);
			break;
		case SDL_MOUSEMOTION :
			if(this->screen_visible == -1) break;
			this->form[this->screen_visible]->do_mousemovement(event.motion.x,event.motion.y);
			break;
	}
}

void Swap_Game::backup_screen()
{
	SDL_Rect screen_space;
	
	//breaker
	if(!this->main_screen) return;
	
	//maker
	if(!this->main_screen_temp)
		this->create_backup_screen_layer();
	
	//breaker
	if(!this->main_screen_temp) return;
	
	//set the boundaries for the blitting
	screen_space.x = 0;
	screen_space.y = 0;
	screen_space.w = this->main_screen->w;
	screen_space.h = this->main_screen->h;
	
	//copy the current screen to temp
	this->draw_mutux(this->main_screen, NULL, this->main_screen_temp, &screen_space);
}

void Swap_Game::unbackup_screen()
{
	SDL_Rect screen_space;
	
	//breaker
	if(!this->main_screen) return;
	
	//maker
	if(!this->main_screen_temp)
		this->create_backup_screen_layer();
	
	//breaker
	if(!this->main_screen_temp) return;
	
	//set the boundaries for the blitting
	screen_space.x = 0;
	screen_space.y = 0;
	screen_space.w = this->main_screen->w;
	screen_space.h = this->main_screen->h;
	
	//copy the current screen to temp
	this->draw_mutux(this->main_screen_temp, NULL, this->main_screen, &screen_space);
}

void Swap_Game::draw_mutux(SDL_Surface *src, SDL_Rect *crop, SDL_Surface *dest, SDL_Rect *dest_loc)
{
	while (this->screen_drawing) SDL_Delay(1);
	
	this->screen_drawing = true;
	SDL_BlitSurface(src, crop, dest, dest_loc);
	this->screen_drawing = false;
}

void Swap_Game::flip_screen()
{
	while (this->screen_flipping) SDL_Delay(1);
	
	this->screen_flipping = true;
# ifdef CAANOO
  SDL_SoftStretch( this->main_screen, NULL, this->real_screen, NULL );
	SDL_Flip(this->real_screen);
# else
	SDL_Flip(this->main_screen);
# endif
	this->screen_flipping = false;
}

void Swap_Game::flip_screen_layered()
{
	SDL_Rect screen_space;
	
	//make sure all the requireds exist
	if(!this->layered_screen) return;
	if(!this->main_screen) return;
	if(!this->main_screen_temp) return;
	
	//set the boundaries for the blitting
	screen_space.x = 0;
	screen_space.y = 0;
	screen_space.w = this->main_screen->w;
	screen_space.h = this->main_screen->h;
	
	
	//copy the current screen to temp
	this->backup_screen();
	
	//copy the layered surface onto the main screen
	//SDL_SetAlpha(this->layered_screen,SDL_RLEACCEL|SDL_SRCALPHA,255);
	this->draw_mutux(this->layered_screen, NULL, this->main_screen, &screen_space);
	
	//flip
	this->flip_screen();
	
	//copy the temp surface back to the normal main screen surface
	this->unbackup_screen();
}

void Swap_Game::clear_screen_layered()
{
	SDL_Rect clear_space;
	
	//these could cause problems...
	if(!this->layered_screen)
		this->create_second_screen_layer();
	
	//exit if it for some reason still doesnt exist
	if(!this->layered_screen) return;
	
	//set the boundaries for the fillrect
	clear_space.x = 0;
	clear_space.y = 0;
	clear_space.w = this->layered_screen->w;
	clear_space.h = this->layered_screen->h;
	
	//set the clear pixel
	this->draw_mutux(this->main_screen, NULL, this->layered_screen, &clear_space);
	//SDL_FillRect(this->layered_screen,&clear_space,SDL_MapRGBA(this->layered_screen->format, 255,255,255,0));
	
	//set that pixel as transparent
	//SDL_SetColorKey(this->layered_screen, SDL_SRCCOLORKEY, SDL_MapRGBA(this->layered_screen->format, 255,255,255,255));
}

double Swap_Game::current_time()
{
	struct timeb new_time;
	
	ftime(&new_time); //init purposes
	return (new_time.time - this->time_offset) + (new_time.millitm * 0.001);
}

void Swap_Game::init_time()
{
	this->time_offset = time(0);
}

void Swap_Game::init_randomizer()
{
	srand(time(0));
}

int Swap_Game::init_audio()
{
	SDL_AudioSpec fmt;
	
	/* Set 16-bit stereo audio at 22Khz */
# ifdef CAANOO
	fmt.freq = 44100;
	fmt.format = AUDIO_S16;
	fmt.channels = 2;
	fmt.samples = 1024;
	fmt.callback = mixaudio;
	fmt.userdata = NULL;
# else
	fmt.freq = 22050;
	fmt.format = AUDIO_S16;
	fmt.channels = 2;
	fmt.samples = 512;        /* A good value for games */
	fmt.callback = mixaudio;
	fmt.userdata = NULL;
# endif
	
	if (SDL_OpenAudio(&fmt, NULL) < 0) {
		printf("Unable to open audio: %s\n", SDL_GetError());
		return 0;
	}

	SDL_PauseAudio(0);
	
	sounds_on = 1;
	
	return 1;
}

int Swap_Game::make_sound(char *filename)
{
	int i;
	SDL_AudioCVT cvt;
	
	i = this->sound_max;

	/* Load the WAV */
	SDL_LoadWAV(filename, &this->game_sound[i].sound_info, &this->game_sound[i].data, &this->game_sound[i].dlen);
	
	//convert it
	SDL_BuildAudioCVT(&cvt, this->game_sound[i].sound_info.format, this->game_sound[i].sound_info.channels, this->game_sound[i].sound_info.freq, AUDIO_S16, 2, 22050);
	cvt.buf = (Uint8 *)malloc(this->game_sound[i].dlen * cvt.len_mult);
	memcpy(cvt.buf, this->game_sound[i].data, this->game_sound[i].dlen);
	cvt.len = this->game_sound[i].dlen;
	SDL_ConvertAudio(&cvt);
	SDL_FreeWAV(this->game_sound[i].data);

	SDL_LockAudio();
	this->game_sound[i].data = cvt.buf;
	this->game_sound[i].dlen = cvt.len_cvt;
	this->game_sound[i].dpos = this->game_sound[i].dlen;
	SDL_UnlockAudio();
	
	
	this->game_sound[i].dpos = this->game_sound[i].dlen;
	
	this->sound_max++;
	
	return i;
}

void Swap_Game::play_sound(int sound_num)
{
	if(!sounds_on) return;
	
	this->game_sound[sound_num].dpos = 0;
}

void mixaudio(void *unused, Uint8 *stream, int len)
{
	int i;
	Uint32 amount;
	
	for (i = 0; i < main_game->sound_max;i++) 
	{
		amount = (main_game->game_sound[i].dlen - main_game->game_sound[i].dpos);
		
		if (amount > (Uint32)len) 
			amount = len;
		
		SDL_MixAudio(stream, &main_game->game_sound[i].data[main_game->game_sound[i].dpos], amount, SDL_MIX_MAXVOLUME);
		main_game->game_sound[i].dpos += amount;
	}
}
