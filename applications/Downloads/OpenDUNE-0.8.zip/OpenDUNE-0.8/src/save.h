/** @file src/save.h Save definitions. */

#ifndef SAVE_H
#define SAVE_H

extern bool SaveGame_SaveFile(char *filename, char *description);

#endif /* SAVE_H */
