/*
** thinlib (c) 2001 Matthew Conte (matt@conte.com)
**
**
** tl_prof.h
**
** Screen border color profiler.
**
** $Id: $
*/

#ifndef _TL_PROF_H_
#define _TL_PROF_H_

extern void thin_prof_setborder(int pal_index);

#endif /* !_TL_PROF_H_ */

/*
** $Log: $
*/
