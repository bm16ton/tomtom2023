#include "main.h"

//our very own "screen number"
int screen_playchoice;

//our button numbers...
int screen_playchoice_button_play;
int screen_playchoice_button_moves;
int screen_playchoice_button_time;

//the game type we choose
int playchoice_option;

//some off beat images
SDL_Surface *playchoice_select_img;
SDL_Surface *playchoice_select_moves_img;
SDL_Surface *playchoice_select_time_img;

//local prototypes
void select_option(int i);

void load_screen_playchoice()
{
	//setup the transparency colors for these images
	SDL_SetColorKey(playchoice_select_img, SDL_SRCCOLORKEY, SDL_MapRGB(playchoice_select_img->format, 255,255,255));
	SDL_SetColorKey(playchoice_select_moves_img, SDL_SRCCOLORKEY, SDL_MapRGB(playchoice_select_moves_img->format, 255,255,255));
	SDL_SetColorKey(playchoice_select_time_img, SDL_SRCCOLORKEY, SDL_MapRGB(playchoice_select_time_img->format, 255,255,255));
	
	playchoice_option = 0;
	
	select_option(screen_playchoice_button_moves);
}

void button_screen_playchoice(int i)
{
	if(i == screen_playchoice_button_play)
		main_game->load_screen(screen_game);
	else
		select_option(i);
}

void select_option(int i)
{
	if(screen_playchoice_button_moves == i)
	{
		if(playchoice_option == 0)
		{
			playchoice_option = 1;
			main_game->draw(69,271,playchoice_select_img);
			main_game->draw(330,271,playchoice_select_time_img);
		}
	}
	else
	{
		if(playchoice_option == 1)
		{
			playchoice_option = 0;
			main_game->draw(69,271,playchoice_select_moves_img);
			main_game->draw(330,271,playchoice_select_img);
		}
	}
}
