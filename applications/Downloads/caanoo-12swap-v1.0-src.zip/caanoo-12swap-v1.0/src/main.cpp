#include "main.h"

Swap_Game *main_game;

int main(int argc, char **argv)
{
	//make our game
	main_game = new Swap_Game();
	
	//load our intro form
	//the intro form will load the other ones...
	screen_intro = main_game->make_screen("graphics/backround_intro.bmp");
	main_game->get_screen(screen_intro)->set_load_func(load_screen_intro);
	main_game->load_screen(screen_intro);
	
	//run the game
	main_game->run_game();
	
	return 0;
}
