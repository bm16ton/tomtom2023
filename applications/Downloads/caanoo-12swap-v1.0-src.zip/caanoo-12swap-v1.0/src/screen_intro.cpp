#include "main.h"

#define LOAD_CENTER_X 260
#define LOAD_CENTER_Y 380

//our very own "screen number"
int screen_intro;
SDL_Surface *loading_bar[6];
SDL_Surface *loaded_bar;
SDL_Surface *icon;

//our attempt at making life easier
void display_loaded_bar(int images_loaded);
void setup_face_templates();
void setup_game_board_buttons();
void setup_face_blink_template();
void setup_face_hint_template();
void setup_face_sad_template();
void load_round_imgs();

void load_screen_intro()
{
	int i,k;
	char filename[200];
	
	//load the icon
	icon = SDL_LoadBMP("graphics/icon.bmp");
	SDL_WM_SetIcon(icon, NULL);
	
	//load the loading bar
	loaded_bar = SDL_LoadBMP("graphics/loaded_bar.bmp");
	SDL_SetColorKey(loaded_bar, SDL_SRCCOLORKEY, SDL_MapRGB(loaded_bar->format, 255,255,255));
	for(i=0;i<6;i++)
	{
		sprintf(filename,"graphics/load_bar_%d.bmp",i);
		loading_bar[i] = SDL_LoadBMP(filename);
		SDL_SetColorKey(loading_bar[i], SDL_SRCCOLORKEY, SDL_MapRGB(loading_bar[i]->format, 255,255,255));
	}
	
	//bring up the loading bar
	for(i=0;i<6;i++)
	{
		main_game->draw(LOAD_CENTER_X - (loading_bar[i]->w / 2), LOAD_CENTER_Y - (loading_bar[i]->h / 2), loading_bar[i]);
		SDL_Delay(20);
	}
	
	//display the loading bar while loading things
	i = 0;
	screen_intro2 = main_game->make_screen("graphics/backround_intro2.bmp");
	display_loaded_bar(++i);
	screen_game = main_game->make_screen("graphics/backround_game.bmp");
	display_loaded_bar(++i);
	screen_gameover = main_game->make_screen("graphics/backround_gameover.bmp");
	display_loaded_bar(++i);
	screen_instructions = main_game->make_screen("graphics/backround_instructions.bmp");
	display_loaded_bar(++i);
	screen_playchoice = main_game->make_screen("graphics/backround_playchoice.bmp");
	display_loaded_bar(++i);
	
	//make their buttons
	
	//instruction buttons
	screen_instructions_button_play = main_game->get_screen(screen_instructions)->make_button(384,368,"graphics/buttons/instructions_play_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_instructions)->get_button(screen_instructions_button_play)->load_mouse_over_img("graphics/buttons/instructions_play_over.bmp");
	display_loaded_bar(++i);
	
	//playchoice buttons
	screen_playchoice_button_play = main_game->get_screen(screen_playchoice)->make_button(223,414,"graphics/buttons/playchoice_play_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_playchoice)->get_button(screen_playchoice_button_play)->load_mouse_over_img("graphics/buttons/playchoice_play_over.bmp");
	display_loaded_bar(++i);
	screen_playchoice_button_moves = main_game->get_screen(screen_playchoice)->make_button(74,275,"graphics/buttons/playchoice_moves_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_playchoice)->get_button(screen_playchoice_button_moves)->load_mouse_over_img("graphics/buttons/playchoice_moves_over.bmp");
	display_loaded_bar(++i);
	screen_playchoice_button_time = main_game->get_screen(screen_playchoice)->make_button(335,275,"graphics/buttons/playchoice_time_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_playchoice)->get_button(screen_playchoice_button_time)->load_mouse_over_img("graphics/buttons/playchoice_time_over.bmp");
	display_loaded_bar(++i);
	
	//main game buttons
	screen_game_button_pause = main_game->get_screen(screen_game)->make_button(22,263,"graphics/buttons/game_pause_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_game)->get_button(screen_game_button_pause)->load_mouse_over_img("graphics/buttons/game_pause_over.bmp");
	display_loaded_bar(++i);
	screen_game_button_resume = main_game->get_screen(screen_game)->make_button(22,263,"graphics/buttons/game_resume_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_game)->get_button(screen_game_button_resume)->load_mouse_over_img("graphics/buttons/game_resume_over.bmp");
	display_loaded_bar(++i);
	screen_game_button_sound_off = main_game->get_screen(screen_game)->make_button(22,325,"graphics/buttons/game_sounds_off_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_game)->get_button(screen_game_button_sound_off)->load_mouse_over_img("graphics/buttons/game_sounds_off_over.bmp");
	display_loaded_bar(++i);
	screen_game_button_sound_on = main_game->get_screen(screen_game)->make_button(22,325,"graphics/buttons/game_sounds_on_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_game)->get_button(screen_game_button_sound_on)->load_mouse_over_img("graphics/buttons/game_sounds_on_over.bmp");
	display_loaded_bar(++i);
	screen_game_button_new_game = main_game->get_screen(screen_game)->make_button(22,387,"graphics/buttons/game_newgame_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_game)->get_button(screen_game_button_new_game)->load_mouse_over_img("graphics/buttons/game_newgame_over.bmp");
	display_loaded_bar(++i);
	screen_game_button_hint = main_game->get_screen(screen_game)->make_button(22,450,"graphics/buttons/game_hint_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_game)->get_button(screen_game_button_hint)->load_mouse_over_img("graphics/buttons/game_hint_over.bmp");
	display_loaded_bar(++i);
	
	//gameover button
	screen_gameover_button_playagain = main_game->get_screen(screen_gameover)->make_button(220,369,"graphics/buttons/gameover_playagain_off.bmp");
	display_loaded_bar(++i);
	main_game->get_screen(screen_gameover)->get_button(screen_gameover_button_playagain)->load_mouse_over_img("graphics/buttons/gameover_playagain_over.bmp");
	display_loaded_bar(++i);
	
	//load some "other" images
	playchoice_select_img = SDL_LoadBMP("graphics/buttons/playchoice_select.bmp");
	display_loaded_bar(++i);
	playchoice_select_moves_img = SDL_LoadBMP("graphics/buttons/playchoice_moves_select_off.bmp");
	display_loaded_bar(++i);
	playchoice_select_time_img = SDL_LoadBMP("graphics/buttons/playchoice_time_select_off.bmp");
	display_loaded_bar(++i);
	dropcover = SDL_LoadBMP("graphics/game_dropcover.bmp");
	SDL_SetColorKey(dropcover, SDL_SRCCOLORKEY, SDL_MapRGB(dropcover->format, 255,255,255));
	display_loaded_bar(++i);
	game_progress_bar = SDL_LoadBMP("graphics/game_progress_bar.bmp");
	SDL_SetColorKey(game_progress_bar, SDL_SRCCOLORKEY, SDL_MapRGB(game_progress_bar->format, 255,255,255));
	display_loaded_bar(++i);
	game_progress_bar_empty = SDL_LoadBMP("graphics/game_progress_bar_empty.bmp");
	SDL_SetColorKey(game_progress_bar_empty, SDL_SRCCOLORKEY, SDL_MapRGB(game_progress_bar_empty->format, 255,255,255));
	display_loaded_bar(++i);
	game_selector = SDL_LoadBMP("graphics/game_selector.bmp");
	SDL_SetColorKey(game_selector, SDL_SRCCOLORKEY, SDL_MapRGB(game_selector->format, 255,255,255));
	display_loaded_bar(++i);
	load_round_imgs();
	display_loaded_bar(++i);
	
	//load faces
	//consider all faces as one image, since the ammount can be variable.
	for(face_max=0;1;face_max++)
	{
		sprintf(filename,"graphics/faces/face%d.bmp",face_max);
		game_face[face_max] = SDL_LoadBMP(filename);
		
		//exit condition - not loaded hmm?
		if(!game_face[face_max]) break;
		
		//since it is loaded...
		SDL_SetColorKey(game_face[face_max], SDL_SRCCOLORKEY, SDL_MapRGB(game_face[face_max]->format, 255,255,255));
	}
	display_loaded_bar(++i);
	//load the main face template
	face_template = SDL_LoadBMP("graphics/faces/main_template.bmp");
	SDL_SetColorKey(face_template, SDL_SRCCOLORKEY, SDL_MapRGB(face_template->format, 255,255,255));
	display_loaded_bar(++i);
	//load all another animation/templates
	setup_face_blink_template();
	display_loaded_bar(++i);
	setup_face_hint_template();
	display_loaded_bar(++i);
	setup_face_sad_template();
	display_loaded_bar(++i);
	
	//"setup" the faces and their templates etc...
	setup_face_templates();
	//setup the buttons layouts
	setup_game_board_buttons();
	
	//hide the buttons that start hidden
	main_game->get_screen(screen_game)->get_button(screen_game_button_resume)->deactivate();
	main_game->get_screen(screen_game)->get_button(screen_game_button_sound_on)->deactivate();
	
	//the the other form functions....
	main_game->get_screen(screen_intro2)->set_load_func(load_screen_intro2);
	main_game->get_screen(screen_instructions)->set_buttonpress_func(button_screen_instructions);
	main_game->get_screen(screen_playchoice)->set_load_func(load_screen_playchoice);
	main_game->get_screen(screen_playchoice)->set_buttonpress_func(button_screen_playchoice);
	main_game->get_screen(screen_game)->set_load_func(load_screen_game);
	main_game->get_screen(screen_game)->set_buttonpress_func(button_screen_game);
	main_game->get_screen(screen_game)->set_buttonover_func(motion_screen_game);
	main_game->get_screen(screen_gameover)->set_load_func(load_screen_gameover);
	main_game->get_screen(screen_gameover)->set_buttonpress_func(button_screen_gameover);
	
	//load the sounds
	sound_roundstart = main_game->make_sound("sounds/sound_roundstart.wav");
	sound_badchoice = main_game->make_sound("sounds/sound_badchoice.wav");
	sound_goodchoice = main_game->make_sound("sounds/sound_goodchoice.wav");
	
	//delay 2 seconds and load next screen
	SDL_Delay(2000);
	main_game->fade_screen(screen_intro2);
}

void display_loaded_bar(int images_loaded)
{
	const int image_amt = 40;
	char percent_amt[50];
	double percentage;
	
	//set the percentage
	percentage = 1.0 * images_loaded / image_amt;
	
	//load up the previous under image to clear out the previous text
	if(percentage < .6)
		main_game->draw_noflip(LOAD_CENTER_X - (loading_bar[5]->w / 2), LOAD_CENTER_Y - (loading_bar[5]->h / 2), loading_bar[5]);
	
	main_game->draw_noflip(LOAD_CENTER_X - (loaded_bar->w / 2), LOAD_CENTER_Y - (loaded_bar->h / 2), loaded_bar, 0, 0, (int)(loaded_bar->w * percentage), loaded_bar->h);
	
	//set and display text
	sprintf(percent_amt,"%d%c",(int)(100 * percentage),37);
	main_game->draw_text(LOAD_CENTER_X,LOAD_CENTER_Y,percent_amt);
}

void setup_face_blink_template()
{
	int i,k;
	char filename[200];
	SDL_Surface *temp_template[FACE_TEMPLATE_MAX];
	Uint32 rmask, gmask, bmask, amask;
	SDL_Rect destination;
	
	//set some defaults...
	destination.x = 0;
	destination.y = 0;
	destination.w = 35;
	destination.h = 35;

  SDL_Surface* g_main_screen = SDL_GetVideoSurface();
  rmask = g_main_screen->format->Rmask;
  gmask = g_main_screen->format->Gmask;
  bmask = g_main_screen->format->Bmask;
  amask = g_main_screen->format->Amask;
  int num_bits = g_main_screen->format->BitsPerPixel;
	
	
	//load all of them
	for(i=0;1;i++) //blink animation
	{
		sprintf(filename,"graphics/faces/blink_template%d.bmp",i);
		temp_template[i] = SDL_LoadBMP(filename);
		
		//exit condition - not loaded hmm?
		if(!temp_template[i]) break;
		
		//since it is loaded...
		SDL_SetColorKey(temp_template[i], SDL_SRCCOLORKEY, SDL_MapRGB(temp_template[i]->format, 255,255,255));
	}

	//make them
	for(k=0;k<face_max;k++)
	{
		for(i=0;temp_template[i];i++)
		{
			//make the surface
			game_face_blink[k][i] = SDL_CreateRGBSurface(SDL_HWSURFACE | SDL_SRCCOLORKEY, 35, 35, num_bits, rmask, gmask, bmask, amask);
			
			SDL_SetColorKey(game_face_blink[k][i], SDL_SRCCOLORKEY,  SDL_MapRGB(game_face_blink[k][i]->format, 0, 0, 0));
			
			//put on this face's backround
			SDL_BlitSurface(game_face[k], NULL, game_face_blink[k][i], &destination);
			
			//put the template on
			SDL_BlitSurface(temp_template[i], NULL, game_face_blink[k][i], &destination);
			
			//set that white to be transparent
			SDL_SetColorKey(game_face_blink[k][i], 0,  SDL_MapRGB(game_face_blink[k][i]->format, 255, 255, 255));
		}
	
		game_face_blink[k][i] = 0; //cap the end like a string
	}
	
	//unload them
	for(i=0;temp_template[i];i++)
		SDL_FreeSurface(temp_template[i]);
}

void setup_face_hint_template()
{
	int i,k;
	char filename[200];
	SDL_Surface *temp_template[FACE_TEMPLATE_MAX];
	Uint32 rmask, gmask, bmask, amask;
	SDL_Rect destination;
	
	//set some defaults...
	destination.x = 0;
	destination.y = 0;
	destination.w = 35;
	destination.h = 35;

  SDL_Surface* g_main_screen = SDL_GetVideoSurface();
  rmask = g_main_screen->format->Rmask;
  gmask = g_main_screen->format->Gmask;
  bmask = g_main_screen->format->Bmask;
  amask = g_main_screen->format->Amask;
  int num_bits = g_main_screen->format->BitsPerPixel;
	
	//load all of them
	for(i=0;1;i++) //blink animation
{
	sprintf(filename,"graphics/faces/hint_template%d.bmp",i);
	temp_template[i] = SDL_LoadBMP(filename);
		
		//exit condition - not loaded hmm?
	if(!temp_template[i]) break;
		
		//since it is loaded...
	SDL_SetColorKey(temp_template[i], SDL_SRCCOLORKEY, SDL_MapRGB(temp_template[i]->format, 255,255,255));
}
	
	//make them
	for(k=0;k<face_max;k++)
{
	for(i=0;temp_template[i];i++)
	{
			//make the surface
		game_face_hint[k][i] = SDL_CreateRGBSurface(SDL_HWSURFACE | SDL_SRCCOLORKEY, 35, 35, num_bits, rmask, gmask, bmask, amask);
			
		//make it transparent
		SDL_SetColorKey(game_face_hint[k][i], SDL_SRCCOLORKEY,  SDL_MapRGB(game_face_hint[k][i]->format, 0, 0, 0));
			
			//put on this face's backround
		SDL_BlitSurface(game_face[k], NULL, game_face_hint[k][i], &destination);
			
			//put the template on
		SDL_BlitSurface(temp_template[i], NULL, game_face_hint[k][i], &destination);
			
			//set that white to be transparent
		SDL_SetColorKey(game_face_hint[k][i], 0,  SDL_MapRGB(game_face_hint[k][i]->format, 255, 255, 255));
	}
	
	game_face_hint[k][i] = 0; //cap the end like a string
}
	
	//unload them
	for(i=0;temp_template[i];i++)
		SDL_FreeSurface(temp_template[i]);
}

void setup_face_sad_template()
{
	int i,k;
	char filename[200];
	SDL_Surface *temp_template[FACE_TEMPLATE_MAX];
	Uint32 rmask, gmask, bmask, amask;
	SDL_Rect destination;
	
	//set some defaults...
	destination.x = 0;
	destination.y = 0;
	destination.w = 35;
	destination.h = 35;

  SDL_Surface* g_main_screen = SDL_GetVideoSurface();
  rmask = g_main_screen->format->Rmask;
  gmask = g_main_screen->format->Gmask;
  bmask = g_main_screen->format->Bmask;
  amask = g_main_screen->format->Amask;
  int num_bits = g_main_screen->format->BitsPerPixel;
	
	//load all of them
	for(i=0;1;i++) //blink animation
{
	sprintf(filename,"graphics/faces/sad_template%d.bmp",i);
	temp_template[i] = SDL_LoadBMP(filename);
		
	//exit condition - not loaded hmm?
	if(!temp_template[i]) break;
		
	//since it is loaded...
	SDL_SetColorKey(temp_template[i], SDL_SRCCOLORKEY, SDL_MapRGB(temp_template[i]->format, 255,255,255));
}
	
	//make them
	for(k=0;k<face_max;k++)
{
	for(i=0;temp_template[i];i++)
	{
			//make the surface
		game_face_sad[k][i] = SDL_CreateRGBSurface(SDL_HWSURFACE | SDL_SRCCOLORKEY, 35, 35, 
                                num_bits, rmask, gmask, bmask, amask);
			
		SDL_SetColorKey(game_face_sad[k][i], SDL_SRCCOLORKEY,  SDL_MapRGB(game_face_sad[k][i]->format, 0, 0, 0));
			
			//put on this face's backround
		SDL_BlitSurface(game_face[k], NULL, game_face_sad[k][i], &destination);
			
			//put the template on
		SDL_BlitSurface(temp_template[i], NULL, game_face_sad[k][i], &destination);
			
			//set that white to be transparent
		SDL_SetColorKey(game_face_sad[k][i], 0,  SDL_MapRGB(game_face_sad[k][i]->format, 255, 255, 255));
	}
	
	game_face_sad[k][i] = 0; //cap the end like a string
}
	
	//unload them
	for(i=0;temp_template[i];i++)
		SDL_FreeSurface(temp_template[i]);
}

void setup_face_templates()
{
	int i;
	SDL_Rect destination;
	
	//setup all the animations
	destination.x = 0;
	destination.y = 0;
	
	//setup the main face templates
	for(i=0;i<face_max;i++)
		SDL_BlitSurface(face_template, NULL, game_face[i], &destination);
}

void setup_game_board_buttons()
{
	int i,k;
	const int x_start = 205;
	const int y_start = 60;
	const int y_spacer = 47;
	const int x_spacer = 50;
	
	//do the first one
	screen_game_button_boardstart = main_game->get_screen(screen_game)->make_button(x_start,y_start,NULL,35,35);
	
	
	for(i=0;i<8;i++)
		for(k=0;k<8;k++)
			if(k || i)
				main_game->get_screen(screen_game)->make_button(x_start + (i * x_spacer), y_start + (k * y_spacer),NULL,35,35);
}

void load_round_imgs()
{
	int i;
	char filename[200];
	
		//load all of them
	for(i=0;1;i++) //blink animation
	{
		sprintf(filename,"graphics/game_round_%d.bmp",i);
		game_round_img[i] = SDL_LoadBMP(filename);
		
	//exit condition - not loaded hmm?
		if(!game_round_img[i]) break;
		
	//since it is loaded...
		SDL_SetColorKey(game_round_img[i], SDL_SRCCOLORKEY, SDL_MapRGB(game_round_img[i]->format, 255,255,255));
		SDL_SetAlpha(game_round_img[i],SDL_RLEACCEL|SDL_SRCALPHA,150);
	}
}
