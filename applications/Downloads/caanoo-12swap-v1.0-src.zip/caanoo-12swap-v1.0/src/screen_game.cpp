#include "main.h"

//our very own "screen number"
int screen_game;

//our button numbers...
int screen_game_button_pause;
int screen_game_button_sound_off;
int screen_game_button_new_game;
int screen_game_button_hint;
int screen_game_button_resume;
int screen_game_button_sound_on;
int screen_game_button_boardstart;

//all the sounds
int sound_roundstart;
int sound_badchoice;
int sound_goodchoice;

//some things that need to be known
int sounds_on;
int game_paused;
int face_max;
int face_choice_max;
int round_number;
int timer_points;
int timer_win_points;
int points;
int old_points;
int timer_old_points;
int win_points;
int old_win_points;
int last_selected_i, last_selected_k;
int board[8][8];

//some off beat images
SDL_Surface *game_face[FACE_MAX];
SDL_Surface *game_face_blink[FACE_MAX][FACE_TEMPLATE_MAX];
SDL_Surface *game_face_hint[FACE_MAX][FACE_TEMPLATE_MAX];
SDL_Surface *game_face_sad[FACE_MAX][FACE_TEMPLATE_MAX];
SDL_Surface *game_round_img[ROUND_ANIM_MAX];
SDL_Surface *face_template;
SDL_Surface *dropcover;
SDL_Surface *game_progress_bar;
SDL_Surface *game_progress_bar_empty;
SDL_Surface *game_selector;

//local prototypes
void pause_game_button_func();
void resume_game_button_func();
void sounds_off_button_func();
void sounds_on_button_func();
void new_game_button_func();
void hint_button_func();
void select_face(int input);
void setup_random_map();
int cap_swap(int i1, int k1, int i2, int k2);
void swap_board(int i1, int k1, int i2, int k2);
int find_all_matches();
void clear_out_matches();
void draw_map();
void draw_raw_map();
void draw_raw_face(int i, int k);
void start_round();
int round_ended();
int has_vertical_match(int i, int k);
int has_horizontal_match(int i, int k);
void drop_row(int i, int to, int ammount);
int award_points(int ammount, int streak);
int find_hint(int *i, int *k);
int could_have_match(int i, int k);
int is_part_of_match(int i, int k);
void draw_score();
void draw_progress_bar();
void set_old_points();
int check_timer_end();
int check_trial_end();

void load_screen_game()
{
	//your starting new game stuff
	round_number = 0;
	timer_points = 0;
	points = 0;
	old_points = 0;
	
	//start the animator
	main_game->get_screen(screen_game)->start_animator_engine();
	
	//start the dang round
	start_round();
	
	//start disolver animator if required
	if(!playchoice_option)
		main_game->get_screen(screen_game)->start_score_disolve_animation();
	
	//load the trail animator if needed
	if(IS_TRIAL)
		main_game->get_screen(screen_game)->start_trial_timer_animation();
}

void button_screen_game(int i)
{
	if(check_timer_end()) return;
	if(check_trial_end()) return;
	
	if(i == screen_game_button_pause)
		pause_game_button_func();
	else if(i == screen_game_button_sound_off)
		sounds_off_button_func();
	else if(i == screen_game_button_new_game)
		new_game_button_func();
	else if(i == screen_game_button_hint)
		hint_button_func();
	else if(i == screen_game_button_resume)
		resume_game_button_func();
	else if(i == screen_game_button_sound_on)
		sounds_on_button_func();
	else if(i >= screen_game_button_boardstart)
		select_face(i - screen_game_button_boardstart);//clicking a face
}

void motion_screen_game(int index, bool is_overtop)
{
	int i,k;
	
	if(check_timer_end()) return;
	if(check_trial_end()) return;
	
	//we only care about the faces
	if(index >= screen_game_button_boardstart)
		index -= screen_game_button_boardstart;
	else
		return;
	
	i = index / 8;
	k = index % 8;
	
	if(is_overtop)
	{
		//start the blink animation
		main_game->get_screen(screen_game)->start_animation(index,game_face_blink[board[i][k]]);
	}
}

void pause_game_button_func()
{
	main_game->get_screen(screen_game)->get_button(screen_game_button_pause)->deactivate();
	main_game->get_screen(screen_game)->get_button(screen_game_button_resume)->activate();
	
}

void resume_game_button_func()
{
	main_game->get_screen(screen_game)->get_button(screen_game_button_resume)->deactivate();
	main_game->get_screen(screen_game)->get_button(screen_game_button_pause)->activate();
	
}

void sounds_off_button_func()
{
	main_game->get_screen(screen_game)->get_button(screen_game_button_sound_off)->deactivate();
	main_game->get_screen(screen_game)->get_button(screen_game_button_sound_on)->activate();
	
	sounds_on = 0;
	
}

void sounds_on_button_func()
{
	main_game->get_screen(screen_game)->get_button(screen_game_button_sound_on)->deactivate();
	main_game->get_screen(screen_game)->get_button(screen_game_button_sound_off)->activate();
	
	sounds_on = 1;
	
}

void new_game_button_func()
{
	main_game->load_screen(screen_playchoice);
}

void hint_button_func()
{
	int i,k;
	
	if(find_hint(&i,&k))
		main_game->get_screen(screen_game)->start_animation((i * 8) + k,game_face_hint[board[i][k]]);
}

void select_face(int input)
{
	int i,k,i_hint,k_hint;
	
	i = input / 8;
	k = input % 8;
	
	//now are we making the choice, or selecting our start
	if(last_selected_i == -1)
	{
		//set the last selected
		last_selected_i = i;
		last_selected_k = k;
		
		//do the animation
		main_game->get_screen(screen_game)->start_selector_animation(input);
	}
	else
	{
		//stop selection animation
		main_game->get_screen(screen_game)->stop_selector_animation();
		
		//check if it is a match
		if(cap_swap(i,k,last_selected_i,last_selected_k))
		{
			swap_board(i,k,last_selected_i,last_selected_k);
			
			//do the animation is_part_of_match
			main_game->get_screen(screen_game)->start_swap_animation(i,k,last_selected_i,last_selected_k, (is_part_of_match(i,k) || is_part_of_match(last_selected_i,last_selected_k)));

			//check if we won the round
			if(find_all_matches())
			{
				//check if we need to end the round
				if(round_ended())
				{
					//win the round..
					start_round();
					return;
				}
				
				//check if we lose
				if(!find_hint(&i_hint,&k_hint))
				{
					//display the end game screen
					main_game->load_screen(screen_gameover);
					return;
				}
			}
			else
			{
				//no matches found so swap back
				swap_board(i,k,last_selected_i,last_selected_k);
			}
			
			//replace top row
			
			
		}
		
		last_selected_i = -1;
		last_selected_k = -1;
	}
}

int cap_swap(int i1, int k1, int i2, int k2)
{
	//check if all inputs are valid
	if(i1 < 0) return 0;
	if(i1 > 7) return 0;
	if(k1 < 0) return 0;
	if(k1 > 7) return 0;
	if(i2 < 0) return 0;
	if(i2 > 7) return 0;
	if(k2 < 0) return 0;
	if(k2 > 7) return 0;
	
	//only one of the directions can have a difference of 1
	if(abs(i1 - i2) + abs(k1 - k2) == 1)
		return 1;
	else
		return 0;
}

void start_round()
{
	//make our little noise
	main_game->play_sound(sound_roundstart);
	
	//increase round number
	round_number++;
	
	//set stuff
	last_selected_i = -1;
	last_selected_k = -1;
	old_win_points = points;
	win_points = points + (120 + (round_number * 120));
	timer_win_points = (win_points - old_win_points);
	timer_points = timer_win_points / 2;
	timer_old_points = 0;
	face_choice_max = 4 + round_number;
	
	//check...
	if(face_choice_max > face_max)
		face_choice_max = face_max;
	
	//make ourselves a new map
	setup_random_map();
	
	//display that map
	draw_map();
	
	//draw our score
	draw_score();
	
	//do the round animation
	main_game->get_screen(screen_game)->start_round_animation(round_number);
}

int round_ended()
{
	//do we have more points then the round equation?
	if(playchoice_option)
		return (points >= win_points);
	else
		return (timer_points >= timer_win_points);
}

void swap_board(int i1, int k1, int i2, int k2)
{
	int temp_value;
	
	temp_value = board[i1][k1];
	board[i1][k1] = board[i2][k2];
	board[i2][k2] = temp_value;
}

void set_old_points()
{
	old_points = points;
	//timer_old_points = timer_points;
}

int award_points(int ammount, int streak)
{
	int new_points;
	
	new_points = (ammount * 10) * streak;
	
	points += new_points;
	timer_points += new_points;
	
	return new_points;
}

int find_all_matches()
{
	int i,k,z, ammount, streak;
	int reset;
	
	//init this
	streak = 0;
	reset = 0;
	
	while(1)
	{
		reset =0;
		
		for(i=0;i<8 && !reset;i++)
			for(k=0;k<8 && !reset;k++)
		{
			if(ammount = has_vertical_match(i,k))
			{
				streak++;
				
				if(streak > 1)
					main_game->get_screen(screen_game)->start_point_animation(i,k,award_points(ammount,streak));
				else
					main_game->get_screen(screen_game)->start_point_animation(last_selected_i, last_selected_k,award_points(ammount,streak));
				drop_row(i,k+(ammount-1),ammount);
				main_game->get_screen(screen_game)->start_drop_row_animation(i,k+(ammount-1),k-1);

				reset = 1;
				break;
			}
			
			if(ammount = has_horizontal_match(i,k))
			{
				streak++;
				
				if(streak > 1)
					main_game->get_screen(screen_game)->start_point_animation(i,k,award_points(ammount,streak));
				else
					main_game->get_screen(screen_game)->start_point_animation(last_selected_i, last_selected_k,award_points(ammount,streak));
				for(z=0;z<ammount;z++)
				{
					drop_row(i+z,k,1);
					main_game->get_screen(screen_game)->start_drop_row_animation(i+z,k,k-1);
				}

				reset = 1;
				break;
			}
		}
		
		//draw the new score
		draw_score();
		
		if(!reset)
			break;
		
		//do this because we have to wait
		main_game->get_screen(screen_game)->pause_while_drop();
	}
	
	return streak;
}

void clear_out_matches()
{
	int i,k,z, ammount;
	int reset;
	
	//init this
	reset = 0;
	
	while(1)
	{
		reset =0;
		
		for(i=0;i<8 && !reset;i++)
			for(k=0;k<8 && !reset;k++)
		{
			if(ammount = has_vertical_match(i,k))
			{
				drop_row(i,k+(ammount-1),ammount);

				reset = 1;
				break;
			}
			
			if(ammount = has_horizontal_match(i,k))
			{
				for(z=0;z<ammount;z++)
					drop_row(i+z,k,1);

				reset = 1;
				break;
			}
		}
		
		if(!reset)
			break;
	}
}

int could_have_match(int i, int k)
{
	//handle all the special cases first
	
	//the L checks
	if(i+2 <= 7 && k+1 <= 7) if(board[i][k] == board[i+1][k+1] && board[i][k] == board[i+2][k+1]) return 1;
	if(i+1 <= 7 && k+2 <= 7) if(board[i][k] == board[i+1][k+1] && board[i][k] == board[i+1][k+2]) return 1;
	if(i-2 >= 0 && k+1 <= 7) if(board[i][k] == board[i-1][k+1] && board[i][k] == board[i-2][k+1]) return 1;
	if(i-1 >= 0 && k+2 <= 7) if(board[i][k] == board[i-1][k+1] && board[i][k] == board[i-1][k+2]) return 1;
	if(i-2 >= 0 && k-1 >= 0) if(board[i][k] == board[i-1][k-1] && board[i][k] == board[i-2][k-1]) return 1;
	if(i-1 >= 0 && k-2 >= 0) if(board[i][k] == board[i-1][k-1] && board[i][k] == board[i-1][k-2]) return 1;
	if(i+2 <= 7 && k-1 >= 0) if(board[i][k] == board[i+1][k-1] && board[i][k] == board[i+2][k-1]) return 1;
	if(i+1 <= 7 && k-2 >= 0) if(board[i][k] == board[i+1][k-1] && board[i][k] == board[i+1][k-2]) return 1;
	
	//V checks
	if(i+1 < 8 && k+1 < 8 && i-1 > -1) if(board[i][k] == board[i+1][k+1] && board[i][k] == board[i-1][k+1]) return 1;
	if(i+1 < 8 && k+1 < 8 && k-1 > -1) if(board[i][k] == board[i+1][k+1] && board[i][k] == board[i+1][k-1]) return 1;
	if(i-1 > -1 && k-1 > -1 && k+1 < 8) if(board[i][k] == board[i-1][k-1] && board[i][k] == board[i-1][k+1]) return 1;
	if(i-1 > -1 && k-1 > -1 && i+1 < 8) if(board[i][k] == board[i-1][k-1] && board[i][k] == board[i+1][k-1]) return 1;
	
	//extended I check
	if(k+3 < 8) if(board[i][k] == board[i][k+2] && board[i][k] == board[i][k+3]) return 1;
	if(k-3 > -1) if(board[i][k] == board[i][k-2] && board[i][k] == board[i][k-3]) return 1;
	if(i-3 > -1) if(board[i][k] == board[i-2][k] && board[i][k] == board[i-3][k]) return 1;
	if(i+3 < 8) if(board[i][k] == board[i+2][k] && board[i][k] == board[i+3][k]) return 1;
	
	return 0;
}

int is_part_of_match(int i, int k)
{
	//horizontal
	if(k+2 < 8) 		if(board[i][k] == board[i][k+1] && board[i][k] == board[i][k+2]) return 1;
	if(k+1 < 8 && k-1 > -1) if(board[i][k] == board[i][k-1] && board[i][k] == board[i][k+1]) return 1;
	if(k-2 > -1) 		if(board[i][k] == board[i][k-2] && board[i][k] == board[i][k-1]) return 1;
	
	//horizontal
	if(i+2 < 8) 		if(board[i][k] == board[i+1][k] && board[i][k] == board[i+2][k]) return 1;
	if(i+1 < 8 && i-1 > -1) if(board[i][k] == board[i-1][k] && board[i][k] == board[i+1][k]) return 1;
	if(i-2 > -1) 		if(board[i][k] == board[i-2][k] && board[i][k] == board[i-1][k]) return 1;
	
	return 0;
}

int find_hint(int *i, int *k)
{
	for(*i=0;*i<8;(*i)++)
		for(*k=0;*k<8;(*k)++)
			if(could_have_match(*i,*k))
				return 1;
	
	return 0;
}

int has_vertical_match(int i, int k)
{
	int z;
	
	for(z=1;z+k<8;z++)
		if(board[i][k] != board[i][k+z])
			break;
	
	if(z >= 3)
		return z;
	else
		return 0;
}

int has_horizontal_match(int i, int k)
{
	int z;
	
	for(z=1;z+i<8;z++)
		if(board[i][k] != board[i+z][k])
			break;
	
	if(z >= 3)
		return z;
	else
		return 0;
}

void drop_row(int i, int to, int ammount)
{
	int z;
	
	for(z=to;z>=0;z--)
	{
		if(z - ammount >= 0) //we got something to take in?
			board[i][z] = board[i][z - ammount];
		else
			board[i][z] = rand() % face_choice_max;
	}
}

void setup_random_map()
{
	int i,k;
	
	for(i=0;i<8;i++)
		for(k=0;k<8;k++)
			board[i][k] = rand() % face_choice_max;
	
	//now...
	clear_out_matches();
}

void draw_map()
{
	int i;
	
	for(i=0;i<8;i++)
		main_game->get_screen(screen_game)->start_drop_row_animation(i,7);
}

void draw_raw_map()
{
	//this function is useless for the animated scene
	int i,k;
	
	for(i=0;i<8;i++)
		for(k=0;k<8;k++)
			draw_raw_face(i,k);
	
	main_game->flip_screen();
}

void draw_raw_face(int i, int k)
{
	const int x_start = 205;
	const int y_start = 60;
	const int y_spacer = 47;
	const int x_spacer = 50;
	
	main_game->draw_noflip(x_start + (i * x_spacer), y_start + (k * y_spacer), game_face[board[i][k]]);
}

void draw_score()
{
	//do the animation
	main_game->get_screen(screen_game)->start_score_animation(old_points,points);
	
	//draw the progess bar, this is as good a place as any to do it
	//draw_progress_bar();
}




void draw_progress_bar()
{
	main_game->draw(192, 453, game_progress_bar, 0, 0, (int)((game_progress_bar->w * (points - old_win_points)) / (win_points - old_win_points)), game_progress_bar->h);
}

int check_timer_end()
{
	if(timer_points < 0)
	{
		main_game->load_screen(screen_gameover);
		return 1;
	}
	else
	{
		return 0;
	}
}

int check_trial_end()
{
	if(!IS_TRIAL)
		return 0;
	
	if(!main_game->get_screen(screen_game)->doing_trial_timer_animation())
	{
		main_game->load_screen(screen_gameover);
		return 1;
	}
	else
	{
		return 0;
	}
}

