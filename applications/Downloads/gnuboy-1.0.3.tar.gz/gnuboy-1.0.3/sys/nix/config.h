/* sys/nix/config.h.  Generated automatically by configure.  */


/* #undef WORDS_BIGENDIAN */
/* #undef SIZEOF_SHORT */
/* #undef SIZEOF_INT */
/* #undef SIZEOF_LONG */

#define HAVE_USLEEP 1
/* #undef HAVE_SELECT */

/* #undef HAVE_MMAP */

/* #undef HAVE_LIBXEXT */
/* #undef HAVE_X11_EXTENSIONS_XSHM_H */
/* #undef HAVE_SYS_IPC_H */
/* #undef HAVE_SYS_SHM_H */

#define HAVE_SYS_SOUNDCARD_H 1
/* #undef HAVE_SOUNDCARD_H */



